# AIDT Annotation Codebook

Version 1.0. Governs `data/segments_labeled.jsonl`.

## Unit of analysis

A **segment** is one sentence occurring inside an AI-related passage of an SEC
filing. Passages were extracted from filings retrieved from the SEC EDGAR
Archives; each segment record carries the accession-level URL of its source
document in the `url` field, so every label can be checked against the primary
source.

Sentences of fewer than 6 or more than 120 words are excluded. Sentences that
contain no AI vocabulary are **retained** when they occur inside an AI-related
passage, because generic filler inside such a passage is itself a category of
interest (see `BOIL`).

## Field 1 — class (`label`)

Assign exactly one of five labels. Work through the decision rule in order.

### 1. `TOOL_CAP` — tool capability claim

The filer, adviser, sub-adviser or fund asserts that AI is used **as a tool in
the investment process**: security selection, ranking, weighting, allocation,
portfolio construction, or forecasting of returns.

This is the class in which AI-washing liability arises under the Advisers Act
antifraud provisions, because it is a representation about the manager's own
capabilities.

> "The Fund is managed using the Bayesian AI Learning Algorithm ("BAILA"), the
> Adviser's proprietary artificial intelligence system."

> "Each day, the EquBot Model ranks each company based on the probability of
> the company benefiting from current economic conditions, trends, and world
> events."

### 2. `TOOL_PROC` — operational / process use

The filer describes AI used for **operations, research support, administration,
productivity or compliance**, without a claim about investment decisions.

The boundary with `TOOL_CAP` is the investment decision. If the sentence
attaches AI to picking, weighting or timing securities, it is `TOOL_CAP`. If it
attaches AI to producing documents, summarising research, automating workflow
or overseeing policy, it is `TOOL_PROC`.

> "AI Tools have been, or are in the process of being, implemented to varying
> degrees to enhance employee productivity, synthesize materials and automate
> routine tasks."

### 3. `EXPOSURE` — AI as an investment theme

AI appears as a property of **what the portfolio holds**, not of how it is
managed: index construction, sector definitions, characteristics of AI-sector
issuers, thematic screens.

Do not code `TOOL_CAP` merely because the sentence is specific. An index
methodology can be highly specific and still make no claim about the manager's
own AI capability.

> "The Index Provider scores companies in the eligible universe on a four-point
> thematic exposure scale based on exposure to at least one AI subtheme."

### 4. `HEDGE` — risk, limitation, or disclaimer

AI-related risk, limitation, uncertainty, regulatory exposure, governance
caveat, or an explicit disclaimer of AI use.

An explicit statement of **non-use** is `HEDGE`, not `TOOL_CAP`, because its
communicative function is defensive.

> "While the Adviser does not currently use AI to make investment
> recommendations, the use of AI could also exacerbate or create new and
> unpredictable risks."

### 5. `BOIL` — non-AI-specific boilerplate

Generic language inside an AI passage that makes no AI-specific assertion:
fund mechanics, administrative or amendment text, generic market or management
risk, legal disclaimers, definitional filler.

A sentence with no AI vocabulary is `BOIL` unless it continues an explicitly
AI-specific proposition from the same passage.

> "The achievement of the investment objective of the Fund cannot be
> guaranteed and the Adviser's management of the Fund may not produce the
> intended results."

### Decision rule

1. Does the sentence make an AI-specific assertion at all? If no → `BOIL`.
2. Is its communicative function defensive (risk, limitation, non-use)? If yes
   → `HEDGE`.
3. Is AI predicated of the portfolio's holdings rather than of the manager? If
   yes → `EXPOSURE`.
4. Is AI attached to an investment decision? If yes → `TOOL_CAP`, otherwise
   → `TOOL_PROC`.

## Field 2 — claim specificity (`spec`)

An ordinal rating in {0, 1, 2, 3}, assigned independently of the class. It
measures how **verifiable** the AI content is — how much an examiner could
check against the firm's books.

| Rating | Criterion | Example |
|---|---|---|
| 0 | No AI content, or purely generic language | "The achievement of the investment objective of the Fund cannot be guaranteed." |
| 1 | Generic AI mention, no checkable particulars | "Recent technological advances in AI pose risks to the Company, the Adviser, and our portfolio investments." |
| 2 | A named system, vendor or technique, **or** a named concrete function | "EquBot, the Fund's sub-adviser, is a technology based company focused on applying artificial intelligence based solutions to investment analyses." |
| 3 | A named system **together with** a concrete mechanism, threshold, quantity or date | "The EquBot Model limits the weight of any individual company to 10%." |

Length is not specificity. A long hedging sentence that names nothing is 1.
A short sentence stating a numeric threshold tied to a named model is 3.

## Field reference

| Field | Meaning |
|---|---|
| `seg_id` | Segment identifier, `S0001`–`S0254` |
| `doc_id` | Source document identifier |
| `cik` | SEC Central Index Key of the registrant |
| `company` | Registrant name as filed |
| `form` | EDGAR form type |
| `filed` | Filing date, `YYYY-MM-DD` |
| `channel` | `bdc`, `fund`, or `manager` |
| `section` | `strategy` or `risk` — the passage type the segment came from |
| `url` | Accession-level EDGAR URL of the source filing |
| `text` | The segment |
| `n_words` | Token count |
| `has_ai_term` | Whether the segment contains AI vocabulary |
| `exact_dup` | Whether an identical normalised segment appeared earlier |
| `label` | AIDT class (this codebook, Field 1) |
| `spec` | Claim specificity rating (this codebook, Field 2) |

## Scope note

The corpus is a purposive sample: passages containing AI language were sought
across issuer types, form types and filing years in order to obtain sufficient
variety in both the promotional and defensive registers to support an
annotation study. It is not a random draw from the EDGAR filing population, and
prevalence statistics computed on it describe the corpus rather than the
population.
