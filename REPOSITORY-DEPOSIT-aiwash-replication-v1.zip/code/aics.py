"""
AICS -- AI Claim Specificity Index.

A transparent, five-facet instrument that scores a disclosure segment on how
verifiable its AI content is.  Every facet is computed from surface evidence
that a human auditor can re-check against the filing text, so a score can
always be traced back to the tokens that produced it.

Facets
------
A  AGENT       an identified actor is bound to the AI predicate
R  ARTIFACT    a named / defined AI system, vendor or technique appears
F  FUNCTION    a concrete operational function is specified
V  EVIDENCE    verifiable quantitative or temporal detail is supplied
C  COMMITMENT  the statement is asserted rather than hedged

AICS = sum_k w_k * f_k  with equal default weights (w_k = 1/5).
"""
import re

# ----------------------------------------------------------------------------
# lexicons (all lower-case matching)
# ----------------------------------------------------------------------------

AI_CORE = [
    'artificial intelligence', 'machine learning', 'deep learning',
    'neural network', 'large language model', 'generative ai', 'genai',
    'natural language processing', 'predictive data analytics', 'chatgpt',
    'ai tools', 'ai technolog', 'ai model', 'ai system', 'ai-driven',
    'ai-enabled', 'ai-powered', 'machine learning technolog', ' ai ',
]

# named / defined artifacts: vendors, branded systems, concrete technique names
ARTIFACT_NAMED = [
    'watson', 'equbot', 'qraft', 'aqua', 'baila', 'openai', 'chatgpt',
    'discover alpha', 'ibm', 'morningstar', 'indxx', 'sei data cloud',
    'large language model', 'neural network', 'natural language processing',
    'robotic process automation', 'bayesian', 'artificial narrow intelligence',
]

ARTIFACT_GENERIC_TECH = [
    'machine learning', 'deep learning', 'generative', 'algorithm',
    'quantitative model', 'ai model', 'ai tools', 'ai technolog',
]

# concrete operational functions
FUNCTION_TERMS = [
    'security selection', 'select equity securities', 'select investments',
    'ranks each company', 'ranks', 'recommends a weight', 'weight of any',
    'purchase and sell', 'purchase and sale', 'portfolio construction',
    'asset allocation', 'allocates', 'screen', 'due diligence', 'sourcing',
    'underwriting', 'valuation', 'risk-management', 'risk management',
    'threat detection', 'anomaly detection', 'behavioral analytics',
    'automate routine tasks', 'synthesize materials', 'employee productivity',
    'operational efficiency', 'compliance', 'reporting', 'proxy voting',
    'investment recommendations', 'investment analys', 'fundamental analysis',
    'pattern', 'forecast', 'triage', 'remediation', 'monitoring',
    'investment decisions', 'security selection process', 'filter data',
    'evaluate', 'analyse', 'analyze', 'analysis of', 'identifies', 'identify',
    'recommendations', 'ranking', 'weight', 'construct', 'automat',
    'detect', 'respond', 'tuning', 'training', 'research', 'diligence',
    'productivity', 'synthesize', 'security selection', 'stock selection',
    'signal', 'scoring', 'classif', 'predict',
]

# actors that can be bound to an AI predicate
AGENT_TERMS = [
    'the fund', 'the adviser', 'the advisor', 'the manager', 'the company',
    'the sub-adviser', "the fund's adviser", 'the investment adviser',
    'the index provider', 'we ', 'our ', 'us ', 'the trust', 'the general partner',
    'the portfolios', 'the model', 'the equbot model', 'the underlying index',
]

# verbs that bind an agent to an AI artifact
USE_VERBS = [
    'uses', 'use ', 'used', 'utilizes', 'utilize', 'utilizing', 'employs',
    'employ', 'applies', 'apply', 'applying', 'leverages', 'leverage',
    'consults', 'deploys', 'deploy', 'implemented', 'implement', 'embedding',
    'embed', 'is managed using', 'managed using', 'developed by', 'licensed',
    'runs on', 'incorporat', 'adopt',
]

# hedging / low-commitment markers
HEDGE_TERMS = [
    'may ', 'might ', 'could ', 'would ', 'possible', 'potential', 'potentially',
    'generally', 'no assurance', 'cannot guarantee', 'not possible to predict',
    'unpredictable', 'is unclear', 'unclear what', 'anticipates', 'expects to',
    'plan to', 'plans to', 'intends to', 'intend to', 'seeks to', 'attempts to',
    'is expected to', 'are expected to', 'inevitably', 'not be in a position',
    'notwithstanding', 'to the extent', 'if third-party', 'risk that',
]

# strong assertive markers
ASSERT_TERMS = [
    'is managed using', 'utilizes the recommendations', 'ranks each company',
    'has licensed', 'have been', 'has been', 'are embedding', 'we are',
    'is designed to select', 'is actively managed', 'invests primarily',
    'consults a database', 'employs a', 'uses an investment process',
    'limits the weight', 'applies its', 'created', 'conducts',
]

NUM_RE = re.compile(r'\b\d+(?:\.\d+)?\s*%|\b\d{1,4}(?:,\d{3})*(?:\.\d+)?\b')
DATE_RE = re.compile(
    r'\b(?:january|february|march|april|may|june|july|august|september|'
    r'october|november|december)\b|\b(?:19|20)\d{2}\b', re.I)
DEFINED_TERM_RE = re.compile(r'[""\"]([A-Za-z][^""\"]{1,40})[""\"]')
PROPER_RE = re.compile(r'\b[A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*){0,3}\b')

STOP_PROPER = {
    'The', 'This', 'These', 'Those', 'Fund', 'Adviser', 'Advisor', 'Company',
    'Manager', 'Trust', 'Board', 'Prospectus', 'Summary', 'Principal',
    'Investment', 'Strategies', 'Risk', 'Risks', 'Artificial', 'Intelligence',
    'Machine', 'Learning', 'Technology', 'Technologies', 'AI', 'In', 'As',
    'For', 'Under', 'While', 'Recent', 'Certain', 'Use', 'Each', 'Any',
    'Portfolio', 'Investments', 'Shares', 'Securities', 'Act', 'Additionally',
    'Because', 'Effective', 'Further', 'Furthermore', 'However', 'Moreover',
    'Notwithstanding', 'There', 'To', 'We', 'Our', 'It', 'If', 'At', 'By',
    'Independent', 'Global', 'Legal', 'Consequently', 'Currently', 'Due',
    'Companies', 'Models', 'Security', 'Cyber', 'Increased', 'Key', 'New',
    'Active', 'Non', 'Equity', 'Foreign', 'Liquidity', 'Premium', 'Concentration',
}


def _count(text, terms):
    return sum(1 for t in terms if t in text)


def _has(text, terms):
    return any(t in text for t in terms)


def facet_scores(text):
    """Return the five facet scores in [0,1] for one segment."""
    low = ' ' + re.sub(r'\s+', ' ', text.lower()) + ' '

    ai_present = _has(low, AI_CORE)

    # ---- A: AGENT ---------------------------------------------------------
    has_agent = _has(low, AGENT_TERMS)
    has_verb = _has(low, USE_VERBS)
    # an agent only counts when it is bound to AI content: the actor, a
    # use-verb and an AI term must appear within a short window of each other.
    bound = False
    if has_agent and has_verb and ai_present:
        toks = low.split()
        ai_pos = [i for i, w in enumerate(toks)
                  if w.startswith('ai') or w in ('intelligence', 'learning')]
        vb_pos = [i for i, w in enumerate(toks)
                  if any(w.startswith(v.strip()) for v in USE_VERBS if v.strip())]
        bound = any(abs(a - b) <= 12 for a in ai_pos for b in vb_pos)
    if bound:
        agent = 1.0
    elif has_agent and has_verb and ai_present:
        agent = 0.7
    elif has_agent and ai_present:
        agent = 0.4
    elif has_agent:
        agent = 0.15
    else:
        agent = 0.0

    # ---- R: ARTIFACT ------------------------------------------------------
    named = _count(low, ARTIFACT_NAMED)
    generic = _count(low, ARTIFACT_GENERIC_TECH)
    defined = len(DEFINED_TERM_RE.findall(text))
    propers = [p for p in PROPER_RE.findall(text)
               if p.split()[0] not in STOP_PROPER and len(p) > 2]
    if named >= 1:
        artifact = min(1.0, 0.6 + 0.2 * named)
    elif defined >= 1 and ai_present:
        artifact = 0.6
    elif len(propers) >= 1 and ai_present:
        artifact = 0.45
    elif generic >= 1:
        artifact = 0.3
    else:
        artifact = 0.0

    # ---- F: FUNCTION ------------------------------------------------------
    fn = _count(low, FUNCTION_TERMS)
    if fn >= 3:
        function = 1.0
    elif fn == 2:
        function = 0.75
    elif fn == 1:
        function = 0.5
    else:
        function = 0.0
    if not ai_present:
        function *= 0.35

    # ---- V: EVIDENCE ------------------------------------------------------
    # only quantitative / temporal detail that is attached to AI content counts;
    # percentages inside generic fund mechanics are not evidence of an AI claim.
    nums = len(NUM_RE.findall(text))
    dates = len(DATE_RE.findall(text))
    spans = len(re.findall(
        r'\b(?:ten|five|three|twelve|twenty)\s+(?:years|months)\b|'
        r'\bup to \d+\b|\beach day\b|\bdaily\b|\bquarterly\b|'
        r'\bas of \w+ \d', low))
    raw = 0.3 * nums + 0.25 * dates + 0.45 * spans
    evidence = min(1.0, raw) * (1.0 if ai_present else 0.15)

    # ---- C: COMMITMENT ----------------------------------------------------
    h = _count(low, HEDGE_TERMS)
    a = _count(low, ASSERT_TERMS)
    commitment = 1.0 / (1.0 + 0.9 * h) + 0.25 * min(a, 2)
    commitment = max(0.0, min(1.0, commitment))

    return {'A': agent, 'R': artifact, 'F': function,
            'V': evidence, 'C': commitment}


DEFAULT_W = {'A': 0.2, 'R': 0.2, 'F': 0.2, 'V': 0.2, 'C': 0.2}


def aics(text, weights=None):
    """Scalar AI Claim Specificity Index in [0,1]."""
    w = weights or DEFAULT_W
    f = facet_scores(text)
    return sum(w[k] * f[k] for k in f)


# ----------------------------------------------------------------------------
# structural features used by the hybrid classifier
# ----------------------------------------------------------------------------

FIRST_PERSON = [' we ', ' our ', ' us ', ' the company ', ' the fund ']
THIRD_PARTY = ['third-party', 'third party', 'counterpart', 'portfolio compan',
               'these companies', 'such companies', 'issuers']
RISK_CUE = ['risk', 'adverse', 'no assurance', 'may not', 'fail', 'loss',
            'liabilit', 'penalt', 'error', 'inaccura', 'disrupt', 'harm',
            'unpredictable', 'cannot', 'obsolete', 'breach']
THEME_CUE = ['invest at least', 'net assets', 'underlying index', 'index',
             'holdings', 'exposure to', 'companies involved', 'issuers',
             'thematic', 'sector']
OPS_CUE = ['productivity', 'routine tasks', 'operational efficiency',
           'administrative', 'workflows', 'reporting', 'compliance',
           'back office', 'employee']


def structural_features(text):
    low = ' ' + re.sub(r'\s+', ' ', text.lower()) + ' '
    f = facet_scores(text)
    n_words = len(text.split())
    return {
        'aics_A': f['A'], 'aics_R': f['R'], 'aics_F': f['F'],
        'aics_V': f['V'], 'aics_C': f['C'],
        'aics': sum(DEFAULT_W[k] * f[k] for k in f),
        'n_words': min(n_words, 80) / 80.0,
        'n_numerals': min(len(NUM_RE.findall(text)), 6) / 6.0,
        'first_person': float(_has(low, FIRST_PERSON)),
        'third_party': float(_has(low, THIRD_PARTY)),
        'risk_cue': min(_count(low, RISK_CUE), 5) / 5.0,
        'theme_cue': min(_count(low, THEME_CUE), 5) / 5.0,
        'ops_cue': min(_count(low, OPS_CUE), 4) / 4.0,
        'hedge_cue': min(_count(low, HEDGE_TERMS), 6) / 6.0,
        'assert_cue': min(_count(low, ASSERT_TERMS), 4) / 4.0,
        'ai_term': float(_has(low, AI_CORE)),
        'defined_term': min(len(DEFINED_TERM_RE.findall(text)), 4) / 4.0,
    }


FEATURE_NAMES = sorted(structural_features('a b c d e f').keys())


def feature_vector(text):
    d = structural_features(text)
    return [d[k] for k in FEATURE_NAMES]
