"""Build the minimal data set required to replicate every finding.

The PLOS ONE editorial decision named five items that must be deposited:
the 254 annotated segments, the AIDT class labels, the AICS scores, the
TemplateGuard family assignments, and the train/test split assignments.
This script writes all five, plus the family-level table, into a single
deposit directory.
"""
import json, os, sys, csv
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import aics as A
from templateguard import cluster, shingles
from sklearn.model_selection import StratifiedKFold, GroupKFold
from collections import defaultdict, Counter
from datetime import date

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
OUT = os.path.join(ROOT, 'deposit')
os.makedirs(OUT, exist_ok=True)

TAU, KSH, SEEDS, NFOLD = 0.5, 5, [0, 1, 2], 5

segs = [json.loads(l) for l in open(os.path.join(ROOT, 'data', 'segments_labeled.jsonl'))]
texts = [s['text'] for s in segs]
y = np.array([s['label'] for s in segs])
docs = np.array([s['doc_id'] for s in segs])
ciks = np.array([s['cik'] for s in segs])
dates = np.array([s['filed'] for s in segs])

# ---- TemplateGuard family assignments -------------------------------------
tmpl = np.array(cluster(texts, tau=TAU, k=KSH, num_perm=128))

# ---- AICS scores: index plus the five facets ------------------------------
facets = [A.facet_scores(t) for t in texts]
aics = [A.aics(t) for t in texts]

# ---- train/test split assignments for all three protocols -----------------
fold = {}
for sd in SEEDS:
    f = np.full(len(y), -1)
    cv = StratifiedKFold(n_splits=NFOLD, shuffle=True, random_state=sd)
    for k, (_, te) in enumerate(cv.split(np.zeros(len(y)), y)):
        f[te] = k
    fold[f'fold_random_seed{sd}'] = f
for name, groups in [('fold_document_disjoint', docs), ('fold_template_disjoint', tmpl)]:
    f = np.full(len(y), -1)
    for k, (_, te) in enumerate(GroupKFold(n_splits=NFOLD).split(np.zeros(len(y)), y, groups)):
        f[te] = k
    fold[name] = f

# ---- near-duplicate flag used by the leakage audit ------------------------
SH = [shingles(t, KSH) for t in texts]
near = {}
for sd in SEEDS:
    v = np.zeros(len(y))
    cv = StratifiedKFold(n_splits=NFOLD, shuffle=True, random_state=sd)
    for tr, te in cv.split(np.zeros(len(y)), y):
        for i in te:
            best = 0.0
            for j in tr:
                u = len(SH[i] | SH[j])
                if u:
                    best = max(best, len(SH[i] & SH[j]) / u)
            v[i] = best
    near[f'max_jaccard_to_train_seed{sd}'] = v

# ---- segment-level table ---------------------------------------------------
cols = (['seg_id', 'doc_id', 'cik', 'company', 'form', 'filed', 'channel',
         'section', 'edgar_url', 'text', 'n_words',
         'aidt_class', 'specificity_rating',
         'aics', 'aics_agent', 'aics_artifact', 'aics_function',
         'aics_evidence', 'aics_commitment',
         'template_family_id', 'template_family_size',
         'template_family_n_registrants', 'in_cross_filer_family']
        + list(fold.keys()) + list(near.keys()))

fam_size = Counter(tmpl.tolist())
fam_regs = defaultdict(set)
for t, c in zip(tmpl, ciks):
    fam_regs[int(t)].add(c)

rows = []
for i, s in enumerate(segs):
    f = facets[i]
    r = {
        'seg_id': s['seg_id'], 'doc_id': s['doc_id'], 'cik': s['cik'],
        'company': s['company'], 'form': s['form'], 'filed': s['filed'],
        'channel': s['channel'], 'section': s['section'], 'edgar_url': s['url'],
        'text': s['text'], 'n_words': s['n_words'],
        'aidt_class': s['label'], 'specificity_rating': s['spec'],
        'aics': round(aics[i], 6),
        'aics_agent': round(f['A'], 6), 'aics_artifact': round(f['R'], 6),
        'aics_function': round(f['F'], 6), 'aics_evidence': round(f['V'], 6),
        'aics_commitment': round(f['C'], 6),
        'template_family_id': int(tmpl[i]),
        'template_family_size': fam_size[int(tmpl[i])],
        'template_family_n_registrants': len(fam_regs[int(tmpl[i])]),
        'in_cross_filer_family': int(len(fam_regs[int(tmpl[i])]) > 1),
    }
    for k, v in fold.items():
        r[k] = int(v[i])
    for k, v in near.items():
        r[k] = round(float(v[i]), 6)
    rows.append(r)

with open(os.path.join(OUT, 'S1_segments_annotated.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)

# ---- family-level table ----------------------------------------------------
fam_rows = []
byfam = defaultdict(list)
for i, t in enumerate(tmpl):
    byfam[int(t)].append(i)
for f, idx in sorted(byfam.items()):
    ds = sorted(dates[i] for i in idx)
    d0, d1 = (date(*map(int, d.split('-'))) for d in (ds[0], ds[-1]))
    fam_rows.append({
        'template_family_id': f, 'size': len(idx),
        'n_registrants': len(fam_regs[f]),
        'first_filed': ds[0], 'last_filed': ds[-1],
        'span_days': (d1 - d0).days,
        'majority_class': Counter(y[idx].tolist()).most_common(1)[0][0],
        'mean_aics': round(float(np.mean([aics[i] for i in idx])), 6),
        'mean_specificity': round(float(np.mean([segs[i]['spec'] for i in idx])), 6),
        'member_seg_ids': ';'.join(segs[i]['seg_id'] for i in idx),
    })
with open(os.path.join(OUT, 'S2_template_families.csv'), 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=list(fam_rows[0].keys()))
    w.writeheader()
    w.writerows(fam_rows)

print('S1_segments_annotated.csv : %d rows x %d cols' % (len(rows), len(cols)))
print('S2_template_families.csv  : %d rows' % len(fam_rows))
print('checks ->',
      'classes', dict(Counter(y.tolist())),
      '| families', len(fam_rows),
      '| cross-filer segments', int(sum(r['in_cross_filer_family'] for r in rows)))
