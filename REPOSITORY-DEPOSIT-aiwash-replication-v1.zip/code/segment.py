"""Segment raw EDGAR document blocks into sentence-level disclosure segments."""
import json, re, os, hashlib

RAW = os.path.join(os.path.dirname(__file__), '..', 'data', 'raw_docs.jsonl')
OUT = os.path.join(os.path.dirname(__file__), '..', 'data', 'segments.jsonl')

ABBR = ['e.g.', 'i.e.', 'Inc.', 'U.S.', 'Corp.', 'No.', 'etc.', 'Ltd.', 'St.',
        'Co.', 'L.P.', 'S.A.', 'Jr.', 'Mr.', 'Ms.', 'Dr.', 'v.', 'vs.']

AI_TERMS = [
    'artificial intelligence', ' ai ', '(ai', 'ai)', 'ai-', ' ai,', ' ai.', 'ai ',
    'machine learning', 'deep learning', 'neural network', 'large language model',
    'generative', 'algorithm', 'chatgpt', 'natural language processing', 'llm',
    'predictive', 'quantitative model', 'watson', 'model'
]


def sent_split(text):
    t = re.sub(r'\s+', ' ', text).strip()
    for a in ABBR:
        t = t.replace(a, a.replace('.', '\x00'))
    parts = re.split(r'(?<=[.!?])\s+', t)
    return [p.replace('\x00', '.').strip() for p in parts]


def is_ai_related(s):
    low = ' ' + s.lower() + ' '
    return any(term in low for term in AI_TERMS)


def main():
    blocks = [json.loads(l) for l in open(RAW)]
    segs, seen = [], set()
    for b in blocks:
        for s in sent_split(b['text']):
            words = s.split()
            if len(words) < 6 or len(words) > 120:
                continue
            # keep all sentences inside AI-focused passages; the presence of an
            # explicit AI term is recorded as a feature, not used as a filter,
            # because generic boilerplate inside AI passages is itself a class.
            key = re.sub(r'[^a-z0-9 ]', '', s.lower())
            sid = 'S%04d' % (len(segs) + 1)
            segs.append({
                'seg_id': sid,
                'doc_id': b['doc_id'],
                'cik': b['cik'],
                'company': b['company'],
                'form': b['form'],
                'filed': b['filed'],
                'channel': b['channel'],
                'section': b['section'],
                'url': b['url'],
                'text': s,
                'n_words': len(words),
                'has_ai_term': is_ai_related(s),
                'exact_dup': key in seen,
            })
            seen.add(key)
    with open(OUT, 'w') as f:
        for s in segs:
            f.write(json.dumps(s) + '\n')
    print('segments written:', len(segs))
    print('unique filers    :', len(set(s['cik'] for s in segs)))
    print('exact duplicates :', sum(s['exact_dup'] for s in segs))
    import collections
    print('by year :', sorted(collections.Counter(s['filed'][:4] for s in segs).items()))
    print('by chan :', dict(collections.Counter(s['channel'] for s in segs)))
    print('by sect :', dict(collections.Counter(s['section'] for s in segs)))
    print('median words:', sorted(s['n_words'] for s in segs)[len(segs) // 2])


if __name__ == '__main__':
    main()
