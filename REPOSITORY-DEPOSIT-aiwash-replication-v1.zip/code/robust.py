"""Cluster-robust re-analysis.

Two changes to the inference reported in the first draft:

1.  The leakage audit previously pooled 254 segments x 3 seeds into 762
    "observations".  Those are not independent.  Here the audit is run per
    (model, seed) replicate, aggregated to one observation per segment, and
    inference is done by bootstrap over clusters (template family, registrant).

2.  The hype-hedge asymmetry previously used a segment-level Mann-Whitney test.
    Segments are clustered by template family and by registrant, so the
    asymmetry is recomputed with family-collapsed estimates and cluster
    bootstrap intervals.
"""
import json, os, sys, warnings
import numpy as np
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')

import pipeline as P                      # reuses corpus, models, splits
import aics as A
from templateguard import shingles

ROOT = P.ROOT
RES = P.RES
texts, y, spec = P.texts, P.y, P.spec
ciks, tmpl, dates = P.ciks, P.tmpl, P.dates
SEEDS = P.SEEDS
KSH = P.KSH

SH = [shingles(t, KSH) for t in texts]


def max_sim(i, train_idx):
    a = SH[i]
    best = 0.0
    for j in train_idx:
        b = SH[j]
        u = len(a | b)
        if u:
            v = len(a & b) / u
            if v > best:
                best = v
    return best


# --------------------------------------------------------------------------
# 1. leakage audit: per model, per seed; similarity cached per split
# --------------------------------------------------------------------------
def leakage_audit():
    # similarity depends only on the split, not on the model
    sim_cache = {}
    for sd in SEEDS:
        sims = np.zeros(len(y))
        for tr, te in P.splits('random', seed=sd):
            for i in te:
                sims[i] = max_sim(i, tr)
        sim_cache[sd] = sims

    models = [k for k in P.make_models(0) if k not in ('Majority class',)]
    per_model = {}
    correct = {}                      # (model, seed) -> per-segment 0/1
    for name in models:
        gaps, an, av = [], [], []
        for sd in SEEDS:
            ok = np.zeros(len(y), dtype=int)
            for tr, te in P.splits('random', seed=sd):
                m = P.make_models(sd)[name]()
                m.fit([texts[i] for i in tr], y[tr])
                p = m.predict([texts[i] for i in te])
                for i, pi in zip(te, p):
                    ok[i] = int(pi == y[i])
            correct[(name, sd)] = ok
            s = sim_cache[sd]
            nd, nv = s >= 0.4, s < 0.4
            an.append(float(ok[nd].mean())); av.append(float(ok[nv].mean()))
            gaps.append(an[-1] - av[-1])
        per_model[name] = {
            'acc_near_dup_mean': float(np.mean(an)),
            'acc_novel_mean': float(np.mean(av)),
            'gap_mean': float(np.mean(gaps)), 'gap_sd': float(np.std(gaps)),
            'gap_per_seed': [float(g) for g in gaps]}
        print(f"  {name:24s} near-dup={np.mean(an):.3f} novel={np.mean(av):.3f} "
              f"gap={np.mean(gaps):+.3f} (sd {np.std(gaps):.3f})")

    # segment-level aggregation for the headline model: majority over seeds
    head = 'AIDT-Hybrid (ours)'
    ok_stack = np.vstack([correct[(head, sd)] for sd in SEEDS])
    seg_ok = (ok_stack.mean(0) >= 0.5).astype(int)
    seg_sim = np.median(np.vstack([sim_cache[sd] for sd in SEEDS]), axis=0)
    nd = seg_sim >= 0.4

    def gap_stat(idx):
        a, b = seg_ok[idx][nd[idx]], seg_ok[idx][~nd[idx]]
        if len(a) == 0 or len(b) == 0:
            return np.nan
        return a.mean() - b.mean()

    def cluster_boot(groups, n=5000, seed=0):
        rng = np.random.default_rng(seed)
        gmap = defaultdict(list)
        for i, g in enumerate(groups):
            gmap[g].append(i)
        keys = list(gmap)
        out = []
        for _ in range(n):
            pick = rng.choice(len(keys), len(keys), replace=True)
            idx = np.concatenate([gmap[keys[k]] for k in pick])
            v = gap_stat(idx)
            if not np.isnan(v):
                out.append(v)
        return [float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))]

    seg_level = {
        'n_segments': int(len(y)),
        'n_near_dup': int(nd.sum()), 'n_novel': int((~nd).sum()),
        'share_near_dup': float(nd.mean()),
        'acc_near_dup': float(seg_ok[nd].mean()),
        'acc_novel': float(seg_ok[~nd].mean()),
        'gap': float(seg_ok[nd].mean() - seg_ok[~nd].mean()),
        'ci95_cluster_template': cluster_boot(tmpl),
        'ci95_cluster_registrant': cluster_boot(ciks),
        'ci95_segment_bootstrap': cluster_boot(np.arange(len(y))),
    }
    print('\n  segment-level (majority over seeds), AIDT-Hybrid:')
    for k, v in seg_level.items():
        print(f'    {k:26s} {v}')

    all_gaps = [per_model[m]['gap_mean'] for m in per_model]
    out = {'per_model': per_model, 'segment_level': seg_level,
           'gap_across_models_mean': float(np.mean(all_gaps)),
           'gap_across_models_min': float(np.min(all_gaps)),
           'gap_across_models_max': float(np.max(all_gaps)),
           'n_models': len(all_gaps),
           'share_test_items_with_near_dup_pooled':
               float(np.mean([ (sim_cache[sd] >= 0.4).mean() for sd in SEEDS ])),
           'sim_bins': []}
    # binned accuracy, segment level, no pooling across seeds
    for lo, hi in [(0.0, 0.2), (0.2, 0.4), (0.4, 0.6), (0.6, 0.8), (0.8, 1.01)]:
        sel = (seg_sim >= lo) & (seg_sim < hi)
        out['sim_bins'].append({'range': f'[{lo:.1f},{hi:.1f})',
                                'n': int(sel.sum()),
                                'accuracy': float(seg_ok[sel].mean()) if sel.sum() else None})
    P.save('leakage_robust', out)
    return out


# --------------------------------------------------------------------------
# 2. cluster-robust hype-hedge asymmetry
# --------------------------------------------------------------------------
def hha_robust():
    eq = np.array([A.aics(t) for t in texts])
    tool = np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])
    hedge = (y == 'HEDGE')
    keep = tool | hedge
    lab = tool[keep].astype(int)
    val = eq[keep]
    sp = spec[keep].astype(float)
    fam = tmpl[keep]
    reg = ciks[keep]

    def diff(v, l):
        return float(v[l == 1].mean() - v[l == 0].mean())

    def collapse(v, l, g):
        """one observation per cluster per class"""
        acc = defaultdict(list)
        for vi, li, gi in zip(v, l, g):
            acc[(gi, li)].append(vi)
        vv = np.array([np.mean(x) for x in acc.values()])
        ll = np.array([k[1] for k in acc])
        return vv, ll

    def cluster_boot(v, l, g, n=5000, seed=0):
        rng = np.random.default_rng(seed)
        gmap = defaultdict(list)
        for i, gi in enumerate(g):
            gmap[gi].append(i)
        keys = list(gmap)
        out = []
        for _ in range(n):
            pick = rng.choice(len(keys), len(keys), replace=True)
            idx = np.concatenate([gmap[keys[k]] for k in pick])
            if l[idx].min() == l[idx].max():
                continue
            out.append(diff(v[idx], l[idx]))
        return [float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))]

    def cluster_perm(v, l, g, n=10000, seed=0):
        """permute the class label at the cluster level"""
        rng = np.random.default_rng(seed)
        gmap = defaultdict(list)
        for i, gi in enumerate(g):
            gmap[gi].append(i)
        keys = list(gmap)
        # cluster's class = majority label of its members
        cl = np.array([int(np.mean(l[gmap[k]]) >= 0.5) for k in keys])
        obs = diff(v, l)
        null = []
        for _ in range(n):
            perm = rng.permutation(cl)
            lp = np.zeros_like(l)
            for k, c in zip(keys, perm):
                lp[gmap[k]] = c
            if lp.min() == lp.max():
                continue
            null.append(diff(v, lp))
        null = np.array(null)
        return float((np.abs(null) >= abs(obs)).mean())

    out = {}
    for nm, v in [('aics', val), ('expert_rating', sp)]:
        vf, lf = collapse(v, lab, fam)
        vr, lr = collapse(v, lab, reg)
        out[nm] = {
            'segment_level': diff(v, lab),
            'n_tool_segments': int((lab == 1).sum()),
            'n_hedge_segments': int((lab == 0).sum()),
            'family_collapsed': float(diff(vf, lf)),
            'n_tool_families': int((lf == 1).sum()),
            'n_hedge_families': int((lf == 0).sum()),
            'registrant_collapsed': float(diff(vr, lr)),
            'n_tool_registrants': int((lr == 1).sum()),
            'n_hedge_registrants': int((lr == 0).sum()),
            'ci95_segment_bootstrap': cluster_boot(v, lab, np.arange(len(v))),
            'ci95_cluster_template': cluster_boot(v, lab, fam),
            'ci95_cluster_registrant': cluster_boot(v, lab, reg),
            'perm_p_cluster_template': cluster_perm(v, lab, fam),
            'perm_p_cluster_registrant': cluster_perm(v, lab, reg),
        }
        print(f'\n  {nm}:')
        for k, vv in out[nm].items():
            print(f'    {k:28s} {vv}')
    P.save('hha_robust', out)
    return out


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if which in ('all', 'leakage'):
        print('=== leakage audit, cluster robust ===')
        leakage_audit()
    if which in ('all', 'hha'):
        print('\n=== hype-hedge asymmetry, cluster robust ===')
        hha_robust()
