"""Generate all figures for the paper."""
import json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import aics as A
from templateguard import cluster, cluster_stats

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
RES = os.path.join(ROOT, 'results')
FIG = os.path.join(ROOT, 'figs')
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    'font.size': 9, 'axes.labelsize': 9, 'axes.titlesize': 9.5,
    'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8,
    'figure.dpi': 200, 'savefig.dpi': 300, 'savefig.bbox': 'tight',
    'axes.spines.top': False, 'axes.spines.right': False,
    'font.family': 'DejaVu Sans',
})

CB = ['#264653', '#2a9d8f', '#e9c46a', '#f4a261', '#e76f51', '#8d99ae']

segs = [json.loads(l) for l in open(os.path.join(ROOT, 'data', 'segments_labeled.jsonl'))]
texts = [s['text'] for s in segs]
y = np.array([s['label'] for s in segs])
spec = np.array([s['spec'] for s in segs])
ciks = np.array([s['cik'] for s in segs])
dates = np.array([s['filed'] for s in segs])
tmpl = np.array(cluster(texts, tau=0.5, k=5))
eq = np.array([A.aics(t) for t in texts])

R = {n: json.load(open(os.path.join(RES, n + '.json')))
     for n in ['corpus', 'protocol_table', 'ablation', 'sensitivity',
               'validation', 'application', 'leakage', 'per_class',
               'leakage_robust', 'hha_robust', 'class_redundancy',
               'novel_subset', 'diffusion']}

CLASSES = ['TOOL_CAP', 'TOOL_PROC', 'EXPOSURE', 'HEDGE', 'BOIL']
NICE = {'TOOL_CAP': 'Tool\ncapability', 'TOOL_PROC': 'Tool\nprocess',
        'EXPOSURE': 'Thematic\nexposure', 'HEDGE': 'Risk\nhedge',
        'BOIL': 'Boiler-\nplate'}


# --------------------------------------------------------------------------
# Fig 1 : framework schematic
# --------------------------------------------------------------------------
def fig_framework():
    fig, ax = plt.subplots(figsize=(7.0, 3.1))
    ax.set_xlim(0, 100); ax.set_ylim(0, 46); ax.axis('off')

    def box(x, yy, w, h, txt, c, fs=7.0, tc=None):
        ax.add_patch(FancyBboxPatch((x, yy), w, h, boxstyle='round,pad=0.5',
                                    fc=c, ec='#33333355', lw=0.7, alpha=.95))
        ax.text(x + w / 2, yy + h / 2, txt, ha='center', va='center',
                fontsize=fs, color=tc or '#1a1a1a', linespacing=1.35)

    def arr(x1, y1, x2, y2, rad=0.0):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>',
                                     mutation_scale=8, lw=0.9, color='#555',
                                     connectionstyle=f'arc3,rad={rad}'))

    for x, lbl in [(9.5, 'Stage 1\ncorpus'), (33, 'Stage 2\ninstruments'),
                   (60, 'Stage 3\nevaluation'), (86, 'Stage 4\nanalysis')]:
        ax.text(x, 43.5, lbl, ha='center', fontsize=7.0, color='#777', linespacing=1.3)

    box(0, 15, 19, 15, 'EDGAR filings\n10-K, 485BPOS, 497,\nN-2, N-CSR, 10-12G\n\n254 segments\n35 filers', CB[0], 6.8, 'white')
    arr(19.5, 22.5, 23.5, 22.5)

    box(24, 25, 18, 12, 'TemplateGuard\nMinHash-LSH\n$\\rightarrow$ families', CB[2], 7.0)
    box(24, 8, 18, 12, 'AICS\n5-facet\nspecificity index', CB[3], 7.0)

    arr(42.5, 31, 50.5, 31)
    arr(42.5, 14, 50.5, 14)
    arr(33, 24.5, 33, 21.5)

    box(51, 25, 20, 12, 'Template-disjoint\ncross-validation', CB[1], 7.0, 'white')
    box(51, 8, 20, 12, 'AIDT-Hybrid\nstacked classifier', CB[4], 7.0, 'white')
    arr(61, 24.5, 61, 21.5)

    arr(71.5, 31, 76.5, 26)
    arr(71.5, 14, 76.5, 19)
    box(77, 12, 22, 21, 'Leakage audit\n\nHype$-$hedge\nasymmetry\n\nDe-templated\nprevalence', '#e4ebef', 7.0)

    box(21, 0, 56, 5.5,
        'expert annotation: 5-class AIDT taxonomy + 0\u20133 specificity rating',
        '#f0f0f0', 6.5)
    arr(9.5, 14.5, 9.5, 2.8)
    arr(20.5, 2.8, 10.0, 2.8)
    fig.savefig(os.path.join(FIG, 'fig1_framework.pdf'))
    plt.close(fig)


# --------------------------------------------------------------------------
# Fig 2 : leakage audit
# --------------------------------------------------------------------------
def fig_leakage():
    LR = R['leakage_robust']
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.6))
    b = [x for x in LR['sim_bins'] if x['accuracy'] is not None]
    xs = np.arange(len(b))
    ax = axes[0]
    ax.bar(xs, [x['accuracy'] for x in b], color=CB[1], width=.68,
           edgecolor='#22222255', lw=.6)
    for i, x in enumerate(b):
        ax.text(i, x['accuracy'] + .012, f"n={x['n']}", ha='center', fontsize=6.6, color='#444')
    ax.set_xticks(xs); ax.set_xticklabels([x['range'] for x in b], fontsize=7)
    ax.set_ylim(.6, 1.08)
    ax.set_xlabel('max shingle-Jaccard similarity to training set')
    ax.set_ylabel('accuracy')
    ax.axhline(LR['segment_level']['acc_novel'], ls='--', lw=.9, color=CB[4])
    ax.text(0.04, LR['segment_level']['acc_novel'] - .05, 'novel segments',
            fontsize=6.8, color=CB[4])
    ax.set_title('(a) Accuracy by near-duplicate similarity', loc='left')

    ax = axes[1]
    pm = LR['per_model']
    names = list(pm)
    gaps = [pm[k]['gap_mean'] for k in names]
    sds = [pm[k]['gap_sd'] for k in names]
    o = np.argsort(gaps)
    cols = [CB[5] if names[i] == 'Keyword rules' else CB[3] for i in o]
    ax.barh(np.arange(len(names)), [gaps[i] for i in o],
            xerr=[sds[i] for i in o], color=cols, edgecolor='#22222255', lw=.6,
            height=.66, error_kw=dict(lw=.7, capsize=1.8, ecolor='#333'))
    ax.set_yticks(np.arange(len(names)))
    ax.set_yticklabels([names[i].replace(' (ours)', '*') for i in o], fontsize=6.6)
    ax.set_xlabel('near-duplicate accuracy advantage')
    ax.set_title('(b) Advantage by model', loc='left')
    ax.axvline(0, color='#888', lw=.7)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig2_leakage.pdf'))
    plt.close(fig)


# --------------------------------------------------------------------------
# Fig 3 : protocol x model
# --------------------------------------------------------------------------
def fig_protocol():
    t = R['protocol_table']
    names = [k for k in t]
    fig, ax = plt.subplots(figsize=(7.0, 3.1))
    w = .26; xs = np.arange(len(names))
    for i, (sch, lab, c) in enumerate([('random', 'random split', CB[3]),
                                       ('document', 'document-disjoint', CB[1]),
                                       ('template', 'template-disjoint', CB[0])]):
        ax.bar(xs + (i - 1) * w, [t[k][sch]['macro_f1'] for k in names], w,
               label=lab, color=c, edgecolor='#22222255', lw=.5)
    ax.set_xticks(xs)
    ax.set_xticklabels([n.replace(' (ours)', '') for n in names],
                       fontsize=6.4, rotation=32, ha='right')
    ax.set_ylabel('macro-F1'); ax.set_ylim(0, .95)
    ax.legend(frameon=False, ncol=3, loc='upper left')
    ax.set_title('Evaluation protocol determines the reported number', loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig3_protocol.pdf'))
    plt.close(fig)


# --------------------------------------------------------------------------
# Fig 4 : AICS by class + validation
# --------------------------------------------------------------------------
def fig_aics():
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.5))
    ax = axes[0]
    data = [eq[y == c] for c in CLASSES]
    bp = ax.boxplot(data, patch_artist=True, widths=.6, showfliers=False)
    for p, c in zip(bp['boxes'], CB):
        p.set_facecolor(c); p.set_alpha(.85); p.set_edgecolor('#333'); p.set_linewidth(.7)
    for m in bp['medians']:
        m.set_color('#111'); m.set_linewidth(1.1)
    ax.set_xticklabels(['Tool\ncap.', 'Tool\nproc.', 'Expo-\nsure', 'Risk\nhedge',
                        'Boiler-\nplate'], fontsize=6.2)
    ax.set_ylabel('AICS'); ax.set_title('(a) AICS by class', loc='left')

    ax = axes[1]
    v = R['validation']
    keys = ['AICS (out-of-fold calibrated)', 'AICS (equal weights)',
            'AI-term count', 'Segment length', 'Numeral count']
    vals = [v[k]['spearman'] for k in keys]
    err = [[v[k]['spearman'] - v[k]['ci95'][0] for k in keys],
           [v[k]['ci95'][1] - v[k]['spearman'] for k in keys]]
    ax.barh(np.arange(len(keys)), vals, xerr=err, color=[CB[0], CB[1], CB[3], CB[4], CB[5]],
            edgecolor='#22222255', lw=.6, height=.62,
            error_kw=dict(lw=.8, capsize=2, ecolor='#333'))
    ax.set_yticks(np.arange(len(keys)))
    ax.set_yticklabels([k.replace(' (out-of-fold calibrated)', '\n(calibrated)')
                         .replace(' (equal weights)', '\n(equal wts)') for k in keys],
                       fontsize=6.6)
    ax.set_xlabel(r'Spearman $\rho$ with expert rating')
    ax.set_xlim(0, .85); ax.set_title('(b) Construct validity', loc='left')

    ax = axes[2]
    fr = R['validation']['facet_rho']
    ks = list('ARFVC')
    ab = R['ablation']
    dl = [-ab['- facet ' + k]['delta'] for k in ks]
    ax.bar(np.arange(5) - .2, [fr[k] for k in ks], .38, label=r'$\rho$ with rating',
           color=CB[1], edgecolor='#22222255', lw=.5)
    ax.bar(np.arange(5) + .2, dl, .38, label='F1 drop when removed',
           color=CB[4], edgecolor='#22222255', lw=.5)
    ax.set_xticks(range(5))
    ax.set_xticklabels(['Agt', 'Art', 'Fun', 'Evi', 'Com'], fontsize=6.6)
    ax.axhline(0, color='#888', lw=.7)
    ax.legend(frameon=False, fontsize=6.2, loc='upper right')
    ax.set_title('(c) Facet contributions', loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig4_aics.pdf'))
    plt.close(fig)


# --------------------------------------------------------------------------
# Fig 5 : templates
# --------------------------------------------------------------------------
def fig_structure():
    fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.25))

    ax = axes[0]
    sizes = sorted(Counter(tmpl.tolist()).values(), reverse=True)
    ax.bar(np.arange(len(sizes)), sizes, color=CB[0], width=1.0)
    ax.set_xlabel('family (rank)'); ax.set_ylabel('segments')
    ax.set_title('(a) Family sizes', loc='left')
    ax.text(.4, .70, f'{len(sizes)} families\n{sum(1 for s_ in sizes if s_==1)} singletons',
            transform=ax.transAxes, fontsize=6.4, color='#333')

    ax = axes[1]
    red = R['class_redundancy']
    ks = ['TOOL_CAP', 'TOOL_PROC', 'EXPOSURE', 'HEDGE', 'BOIL']
    xs = np.arange(len(ks))
    ax.bar(xs - .2, [red[k]['redundancy'] for k in ks], .38,
           label='redundancy', color=CB[0], edgecolor='#22222255', lw=.5)
    ax.bar(xs + .2, [red[k]['cross_filer_share'] for k in ks], .38,
           label='cross-filer', color=CB[3], edgecolor='#22222255', lw=.5)
    ax.set_xticks(xs)
    ax.set_xticklabels(['T-cap', 'T-proc', 'Expo', 'Hedge', 'Boil'],
                       fontsize=6.0, rotation=35)
    ax.set_ylabel('share of segments'); ax.set_ylim(0, .60)
    ax.legend(frameon=False, fontsize=5.8, loc='upper left')
    ax.set_title('(b) Reuse by class', loc='left')

    ax = axes[2]
    tool = np.isin(y, ['TOOL_CAP', 'TOOL_PROC']); hedge = y == 'HEDGE'
    bins = np.linspace(0, 1, 20)
    ax.hist(eq[tool], bins=bins, alpha=.75, label='tool claims', color=CB[1], density=True)
    ax.hist(eq[hedge], bins=bins, alpha=.65, label='risk hedges', color=CB[4], density=True)
    ax.axvline(eq[tool].mean(), color=CB[1], lw=1.3)
    ax.axvline(eq[hedge].mean(), color=CB[4], lw=1.3)
    ax.annotate('', xy=(eq[tool].mean(), 3.4), xytext=(eq[hedge].mean(), 3.4),
                arrowprops=dict(arrowstyle='<->', lw=.8, color='#333'))
    ax.text((eq[tool].mean() + eq[hedge].mean()) / 2, 3.6, 'HHA', ha='center', fontsize=6.4)
    ax.set_ylim(0, 5.0)
    ax.set_xlabel('AICS'); ax.set_ylabel('density')
    ax.legend(frameon=False, fontsize=5.8, loc='upper right')
    ax.set_title('(c) Hype$-$hedge gap', loc='left')

    ax = axes[3]
    sn = R['sensitivity']
    taus = sorted(sn['tau'], key=float)
    ax.plot([float(t) for t in taus], [sn['tau'][t]['macro_f1'] for t in taus],
            'o-', color=CB[0], ms=3.2, lw=1.1)
    ax.set_xlabel(r'LSH threshold $\tau$'); ax.set_ylabel('macro-F1')
    ax2 = ax.twinx()
    ax2.plot([float(t) for t in taus], [sn['tau'][t]['templated_share'] for t in taus],
             's--', color=CB[4], ms=3.0, lw=1.0)
    ax2.set_ylabel('redundancy', color=CB[4], fontsize=8)
    ax2.tick_params(axis='y', colors=CB[4]); ax2.spines['top'].set_visible(False)
    ax.set_title(r'(d) Sensitivity to $\tau$', loc='left')

    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig5_structure.pdf'))
    plt.close(fig)


def fig_estimator():
    NS = R['novel_subset']
    pm, sm = NS['per_model'], NS['summary']
    names = list(pm)
    fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.7))

    ax = axes[0]
    t = np.array([pm[k]['template_f1'] for k in names])
    r = np.array([pm[k]['random_f1'] for k in names])
    n = np.array([pm[k]['novel_subset_f1'] for k in names])
    lim = [0.52, 0.87]
    ax.plot(lim, lim, '--', color='#999', lw=.9, zorder=0)
    ax.scatter(t, r, s=26, color=CB[4], label='random split', zorder=3,
               edgecolor='#33333366', linewidth=.5)
    ax.scatter(t, n, s=26, color=CB[1], marker='s', label='novel-subset estimate',
               zorder=3, edgecolor='#33333366', linewidth=.5)
    for i in range(len(names)):
        ax.plot([t[i], t[i]], [n[i], r[i]], color='#bbb', lw=.6, zorder=1)
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel('template-disjoint macro-F1 (reference)')
    ax.set_ylabel('estimated macro-F1')
    ax.legend(frameon=False, fontsize=6.8, loc='upper left')
    ax.set_title('(a) Estimates against the reference', loc='left')

    ax = axes[1]
    eu = np.array([pm[k]['err_uncorrected_f1'] for k in names])
    ec = np.array([pm[k]['err_corrected_f1'] for k in names])
    o = np.argsort(eu)
    yy = np.arange(len(names))
    ax.barh(yy - .2, [eu[i] for i in o], .38, color=CB[4], label='random split',
            edgecolor='#22222255', lw=.5)
    ax.barh(yy + .2, [ec[i] for i in o], .38, color=CB[1], label='novel subset',
            edgecolor='#22222255', lw=.5)
    ax.set_yticks(yy)
    ax.set_yticklabels([names[i].replace(' (ours)', '*') for i in o], fontsize=6.4)
    ax.axvline(0, color='#666', lw=.8)
    ax.set_xlabel('error relative to template-disjoint macro-F1')
    ax.legend(frameon=False, fontsize=6.6, loc='lower right')
    ax.set_title('(b) Error by model', loc='left')
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, 'fig6_estimator.pdf'))
    plt.close(fig)


for f in [fig_framework, fig_leakage, fig_protocol, fig_aics, fig_structure,
          fig_estimator]:
    f(); print('ok', f.__name__)
print(os.listdir(FIG))
