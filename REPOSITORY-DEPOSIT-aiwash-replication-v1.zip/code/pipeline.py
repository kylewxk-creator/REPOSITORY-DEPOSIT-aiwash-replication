"""Staged experimental pipeline. Usage: python3 pipeline.py <stage>

stages: corpus | protocol | ablation | sensitivity | validation | application
"""
import json, os, sys, warnings
import numpy as np
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,
                              StackingClassifier)
from sklearn.naive_bayes import ComplementNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.metrics import f1_score, accuracy_score, classification_report
from sklearn.dummy import DummyClassifier
from scipy.stats import spearmanr, mannwhitneyu
from scipy.sparse import hstack, csr_matrix

import aics as A
from templateguard import cluster, cluster_stats

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
RES = os.path.join(ROOT, 'results')
os.makedirs(RES, exist_ok=True)

CLASSES = ['TOOL_CAP', 'TOOL_PROC', 'EXPOSURE', 'HEDGE', 'BOIL']
ENFORCEMENT = '2024-03-18'          # SEC's first AI-washing actions
SEEDS = [0, 1, 2]
TAU, KSH = 0.5, 5

# ---------------------------------------------------------------------------
segs = [json.loads(l) for l in open(os.path.join(ROOT, 'data', 'segments_labeled.jsonl'))]
texts = [s['text'] for s in segs]
y = np.array([s['label'] for s in segs])
spec = np.array([s['spec'] for s in segs])
docs = np.array([s['doc_id'] for s in segs])
ciks = np.array([s['cik'] for s in segs])
dates = np.array([s['filed'] for s in segs])
tmpl = np.array(cluster(texts, tau=TAU, k=KSH, num_perm=128))

_CACHE = {}


def struct_matrix(txts):
    return np.array([_CACHE.setdefault(t, A.feature_vector(t)) for t in txts])


def save(name, obj):
    with open(os.path.join(RES, name + '.json'), 'w') as f:
        json.dump(obj, f, indent=1)
    print('saved', name + '.json')


def load(name):
    p = os.path.join(RES, name + '.json')
    return json.load(open(p)) if os.path.exists(p) else {}


# ---------------------------------------------------------------------------
# models
# ---------------------------------------------------------------------------
class Fusion:
    """Early fusion: TF-IDF concatenated with the AICS structural block,
    the latter scaled by alpha."""
    def __init__(self, C=4.0, ngram=(1, 2), max_features=8000, alpha=1.0, seed=0):
        self.C, self.ngram, self.max_features = C, ngram, max_features
        self.alpha, self.seed = alpha, seed

    def fit(self, txts, yy):
        self.tf = TfidfVectorizer(ngram_range=self.ngram, min_df=2,
                                  sublinear_tf=True, max_features=self.max_features)
        Xl = self.tf.fit_transform(txts)
        M = struct_matrix(txts)
        self.sc = StandardScaler().fit(M)
        X = hstack([Xl, csr_matrix(self.sc.transform(M) * self.alpha)]).tocsr()
        self.clf = LogisticRegression(C=self.C, max_iter=4000,
                                      class_weight='balanced', random_state=self.seed)
        self.clf.fit(X, yy)
        return self

    def predict(self, txts):
        X = hstack([self.tf.transform(txts),
                    csr_matrix(self.sc.transform(struct_matrix(txts)) * self.alpha)]).tocsr()
        return self.clf.predict(X)


class Hybrid:
    """AIDT-Hybrid: stacked fusion of a word channel, a character channel and
    the AICS structural channel, combined by a logistic meta-learner trained on
    out-of-fold predictions inside the training split."""
    def __init__(self, seed=0, use_struct=True, use_lex=True, use_char=True,
                 struct_keep=None, C=4.0, ngram=(1, 2), max_features=8000):
        self.seed, self.use_struct = seed, use_struct
        self.use_lex, self.use_char = use_lex, use_char
        self.struct_keep, self.C, self.ngram = struct_keep, C, ngram
        self.max_features = max_features

    def _struct_pipe(self):
        keep = self.struct_keep

        def _f(txts):
            M = struct_matrix(txts)
            if keep is not None:
                M = M[:, [A.FEATURE_NAMES.index(k) for k in keep]]
            return M
        return Pipeline([('f', FunctionTransformer(_f, validate=False)),
                         ('s', StandardScaler()),
                         ('c', GradientBoostingClassifier(n_estimators=120, max_depth=2,
                                                          random_state=self.seed))])

    def fit(self, txts, yy):
        ests = []
        if self.use_lex:
            ests.append(('lex', Pipeline([
                ('v', TfidfVectorizer(ngram_range=self.ngram, min_df=2, sublinear_tf=True,
                                      max_features=self.max_features)),
                ('c', LogisticRegression(C=self.C, max_iter=4000,
                                         class_weight='balanced', random_state=self.seed))])))
        if self.use_char:
            ests.append(('chr', Pipeline([
                ('v', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5), min_df=2,
                                      sublinear_tf=True, max_features=20000)),
                ('c', LogisticRegression(C=self.C, max_iter=4000,
                                         class_weight='balanced', random_state=self.seed))])))
        if self.use_struct:
            ests.append(('aics', self._struct_pipe()))
        if len(ests) == 1:
            self.m = ests[0][1]
        else:
            self.m = StackingClassifier(
                estimators=ests,
                final_estimator=LogisticRegression(max_iter=4000, class_weight='balanced',
                                                   random_state=self.seed),
                cv=3, stack_method='predict_proba', n_jobs=1)
        self.m.fit(txts, yy)
        return self

    def predict(self, txts):
        return self.m.predict(txts)


class RuleBaseline:
    """Transparent keyword rule set, in the spirit of keyword-count disclosure
    studies."""
    def fit(self, txts, yy):
        return self

    def predict(self, txts):
        out = []
        for t in txts:
            low = ' ' + t.lower() + ' '
            if not any(k in low for k in A.AI_CORE):
                out.append('BOIL'); continue
            if any(k in low for k in ['risk', 'no assurance', 'adverse', 'may not',
                                      'cannot', 'unpredictable', 'inaccura', 'fail']):
                out.append('HEDGE'); continue
            if any(k in low for k in ['index', 'net assets', 'invest at least',
                                      'companies involved', 'exposure to', 'holdings']):
                out.append('EXPOSURE'); continue
            if any(k in low for k in ['productivity', 'routine tasks', 'operational',
                                      'workflows', 'administrative']):
                out.append('TOOL_PROC'); continue
            out.append('TOOL_CAP')
        return np.array(out)


def make_models(seed=0):
    return {
        'Majority class': lambda: DummyClassifier(strategy='most_frequent'),
        'Keyword rules': lambda: RuleBaseline(),
        'TF-IDF + ComplementNB': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', ComplementNB())]),
        'TF-IDF + LogReg': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', LogisticRegression(C=4.0, max_iter=4000, class_weight='balanced',
                                     random_state=seed))]),
        'TF-IDF + LinearSVC': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', LinearSVC(class_weight='balanced', random_state=seed))]),
        'Char TF-IDF + LinearSVC': lambda: Pipeline([
            ('v', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5), min_df=2,
                                  sublinear_tf=True, max_features=20000)),
            ('c', LinearSVC(class_weight='balanced', random_state=seed))]),
        'AICS features + RF': lambda: Pipeline([
            ('f', FunctionTransformer(struct_matrix, validate=False)),
            ('c', RandomForestClassifier(n_estimators=400, class_weight='balanced',
                                         random_state=seed))]),
        'AICS features + GBM': lambda: Pipeline([
            ('f', FunctionTransformer(struct_matrix, validate=False)),
            ('s', StandardScaler()),
            ('c', GradientBoostingClassifier(n_estimators=120, max_depth=2,
                                             random_state=seed))]),
        'Early fusion': lambda: Fusion(seed=seed),
        'AIDT-Hybrid (ours)': lambda: Hybrid(seed=seed),
    }


def splits(scheme, n_splits=5, seed=0):
    if scheme == 'random':
        cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(cv.split(np.zeros(len(y)), y))
    groups = docs if scheme == 'document' else tmpl
    return list(GroupKFold(n_splits=n_splits).split(np.zeros(len(y)), y, groups))


def evaluate(model_fn, scheme, seed=0, groups=None):
    f1s, accs = [], []
    sp = (list(GroupKFold(n_splits=5).split(np.zeros(len(y)), y, groups))
          if groups is not None else splits(scheme, seed=seed))
    for tr, te in sp:
        m = model_fn()
        m.fit([texts[i] for i in tr], y[tr])
        p = m.predict([texts[i] for i in te])
        f1s.append(f1_score(y[te], p, average='macro', zero_division=0))
        accs.append(accuracy_score(y[te], p))
    return float(np.mean(f1s)), float(np.mean(accs))


def mean_over_seeds(build, scheme, seeds=SEEDS, groups=None):
    v = [evaluate(lambda sd=sd: build(sd), scheme, sd, groups) for sd in seeds]
    return float(np.mean([a for a, _ in v])), float(np.std([a for a, _ in v])), \
        float(np.mean([b for _, b in v]))


# ---------------------------------------------------------------------------
# stages
# ---------------------------------------------------------------------------
def stage_corpus():
    st = cluster_stats(tmpl)
    reuse = defaultdict(set)
    for t, c in zip(tmpl, ciks):
        reuse[int(t)].add(c)
    out = {
        'n_segments': len(segs), 'n_documents': len(set(docs.tolist())),
        'n_filers': len(set(ciks.tolist())),
        'forms': dict(Counter(s['form'] for s in segs)),
        'channels': dict(Counter(s['channel'] for s in segs)),
        'year_dist': dict(sorted(Counter(d[:4] for d in dates).items())),
        'class_dist': dict(Counter(y.tolist())),
        'spec_dist': {str(k): int(v) for k, v in sorted(Counter(spec.tolist()).items())},
        'median_words': int(np.median([s['n_words'] for s in segs])),
        'exact_dup_rate': float(np.mean([s['exact_dup'] for s in segs])),
        'template_stats': st,
        'n_templates_multi_filer': sum(1 for v in reuse.values() if len(v) > 1),
        'max_filers_per_template': max(len(v) for v in reuse.values()),
        'share_in_crossfiler_templates': float(np.mean([len(reuse[int(t)]) > 1 for t in tmpl])),
        'aics_by_class': {c: {'mean': float(np.mean([A.aics(t) for t, l in zip(texts, y) if l == c])),
                              'sd': float(np.std([A.aics(t) for t, l in zip(texts, y) if l == c])),
                              'n': int((y == c).sum()),
                              'mean_spec': float(spec[y == c].mean())} for c in CLASSES},
    }
    save('corpus', out)
    print(json.dumps({k: v for k, v in out.items() if not isinstance(v, dict)}, indent=1))


def stage_protocol():
    table = load('protocol_table')
    for name in make_models(0):
        if name in table:
            continue
        row = {}
        for scheme in ['random', 'document', 'template']:
            f1, sd, acc = mean_over_seeds(lambda s, n=name: make_models(s)[n](), scheme)
            row[scheme] = {'macro_f1': f1, 'sd': sd, 'accuracy': acc}
        row['optimism_gap'] = row['random']['macro_f1'] - row['template']['macro_f1']
        table[name] = row
        print(f"{name:24s} rand={row['random']['macro_f1']:.3f} "
              f"doc={row['document']['macro_f1']:.3f} tmpl={row['template']['macro_f1']:.3f} "
              f"gap={row['optimism_gap']:+.3f}")
        save('protocol_table', table)
    # per-class report for the proposed model under the strict protocol
    P, T = [], []
    for tr, te in splits('template', seed=0):
        m = Hybrid(seed=0).fit([texts[i] for i in tr], y[tr])
        P += list(m.predict([texts[i] for i in te])); T += list(y[te])
    save('per_class', classification_report(T, P, output_dict=True, zero_division=0))
    print(classification_report(T, P, zero_division=0))


GROUPS = {
    'AICS facets': ['aics_A', 'aics_R', 'aics_F', 'aics_V', 'aics_C', 'aics'],
    'lexical cues': ['risk_cue', 'theme_cue', 'ops_cue', 'hedge_cue', 'assert_cue'],
    'agency markers': ['first_person', 'third_party'],
    'surface features': ['n_words', 'n_numerals', 'ai_term', 'defined_term'],
}


def stage_ablation():
    abl = load('ablation')
    def rec(key, build):
        if key in abl:
            return
        f1, sd, acc = mean_over_seeds(build, 'template')
        abl[key] = {'macro_f1': f1, 'sd': sd}
        save('ablation', abl)
        print(f'  {key:26s} {f1:.3f} +/- {sd:.3f}')
    rec('full model', lambda s: Hybrid(seed=s))
    rec('- word channel', lambda s: Hybrid(seed=s, use_lex=False))
    rec('- character channel', lambda s: Hybrid(seed=s, use_char=False))
    rec('- AICS channel', lambda s: Hybrid(seed=s, use_struct=False))
    rec('AICS channel only', lambda s: Hybrid(seed=s, use_lex=False, use_char=False))
    for g, keys in GROUPS.items():
        keep = [k for k in A.FEATURE_NAMES if k not in keys]
        rec('- ' + g, lambda s, kp=keep: Hybrid(seed=s, struct_keep=kp))
    for f, key in [('A', 'aics_A'), ('R', 'aics_R'), ('F', 'aics_F'),
                   ('V', 'aics_V'), ('C', 'aics_C')]:
        keep = [k for k in A.FEATURE_NAMES if k != key]
        rec('- facet ' + f, lambda s, kp=keep: Hybrid(seed=s, struct_keep=kp))
    base = abl['full model']['macro_f1']
    for k in abl:
        abl[k]['delta'] = abl[k]['macro_f1'] - base
    save('ablation', abl)


def stage_sensitivity():
    sens = load('sensitivity')
    sens.setdefault('tau', {}); sens.setdefault('shingle_k', {})
    sens.setdefault('ngram', {}); sens.setdefault('C', {})
    for tau in [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
        if str(tau) in sens['tau']:
            continue
        lab = np.array(cluster(texts, tau=tau, k=KSH))
        f1, sd, _ = mean_over_seeds(lambda s: Hybrid(seed=s), 'template', groups=lab)
        sens['tau'][str(tau)] = {'macro_f1': f1, 'sd': sd,
                                 'n_clusters': int(len(set(lab.tolist()))),
                                 'templated_share': cluster_stats(lab)['templated_share']}
        save('sensitivity', sens); print('  tau', tau, round(f1, 3))
    for k in [3, 4, 5, 6, 8]:
        if str(k) in sens['shingle_k']:
            continue
        lab = np.array(cluster(texts, tau=TAU, k=k))
        f1, sd, _ = mean_over_seeds(lambda s: Hybrid(seed=s), 'template', groups=lab)
        sens['shingle_k'][str(k)] = {'macro_f1': f1,
                                     'n_clusters': int(len(set(lab.tolist()))),
                                     'templated_share': cluster_stats(lab)['templated_share']}
        save('sensitivity', sens); print('  k', k, round(f1, 3))
    for ng in [(1, 1), (1, 2), (1, 3)]:
        if str(ng) in sens['ngram']:
            continue
        f1, sd, _ = mean_over_seeds(lambda s, n=ng: Hybrid(seed=s, ngram=n), 'template')
        sens['ngram'][str(ng)] = {'macro_f1': f1, 'sd': sd}
        save('sensitivity', sens); print('  ngram', ng, round(f1, 3))
    for C in [0.5, 1.0, 2.0, 4.0, 8.0, 16.0]:
        if str(C) in sens['C']:
            continue
        f1, sd, _ = mean_over_seeds(lambda s, c=C: Hybrid(seed=s, C=c), 'template')
        sens['C'][str(C)] = {'macro_f1': f1, 'sd': sd}
        save('sensitivity', sens); print('  C', C, round(f1, 3))


def stage_leakage():
    """Leakage audit: under a random split, stratify test-item accuracy by the
    maximum near-duplicate similarity to any training item.  This isolates the
    mechanism behind the optimism of random splits."""
    from templateguard import shingles
    sh = [shingles(t, KSH) for t in texts]

    def maxsim(i, tr):
        a = sh[i]
        best = 0.0
        for j in tr:
            b = sh[j]
            u = len(a | b)
            if u:
                best = max(best, len(a & b) / u)
        return best

    rows = []
    for sd in SEEDS:
        for tr, te in splits('random', seed=sd):
            m = Hybrid(seed=sd).fit([texts[i] for i in tr], y[tr])
            pr = m.predict([texts[i] for i in te])
            for i, p in zip(te, pr):
                rows.append({'sim': maxsim(i, tr), 'correct': int(p == y[i])})
    bins = [(0.0, 0.2), (0.2, 0.4), (0.4, 0.6), (0.6, 0.8), (0.8, 1.01)]
    out = {'bins': []}
    for lo, hi in bins:
        sel = [r for r in rows if lo <= r['sim'] < hi]
        out['bins'].append({'range': f'[{lo:.1f},{hi:.1f})', 'n': len(sel),
                            'accuracy': float(np.mean([r['correct'] for r in sel])) if sel else None})
    hi_sim = [r['correct'] for r in rows if r['sim'] >= 0.4]
    lo_sim = [r['correct'] for r in rows if r['sim'] < 0.4]
    out['accuracy_near_dup'] = float(np.mean(hi_sim))
    out['accuracy_novel'] = float(np.mean(lo_sim))
    out['n_near_dup'] = len(hi_sim)
    out['n_novel'] = len(lo_sim)
    out['gap'] = out['accuracy_near_dup'] - out['accuracy_novel']
    from scipy.stats import fisher_exact
    tbl = [[sum(hi_sim), len(hi_sim) - sum(hi_sim)],
           [sum(lo_sim), len(lo_sim) - sum(lo_sim)]]
    out['fisher_p'] = float(fisher_exact(tbl)[1])
    out['share_test_items_with_near_dup'] = len(hi_sim) / len(rows)
    save('leakage', out)
    print(json.dumps(out, indent=1))


def stage_validation():
    eq = np.array([A.aics(t) for t in texts])
    facets = np.array([[A.facet_scores(t)[k] for k in 'ARFVC'] for t in texts])
    base_len = np.array([len(t.split()) for t in texts], float)
    base_num = np.array([len(A.NUM_RE.findall(t)) for t in texts], float)
    base_ai = np.array([sum(k in ' ' + t.lower() + ' ' for k in A.AI_CORE)
                        for t in texts], float)

    def boot(x, yv, n=4000, seed=0):
        rng = np.random.default_rng(seed)
        v = [spearmanr(x[i], yv[i]).statistic
             for i in (rng.integers(0, len(x), len(x)) for _ in range(n))]
        return [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]

    val = {}
    for nm, v in [('AICS (equal weights)', eq), ('Segment length', base_len),
                  ('Numeral count', base_num), ('AI-term count', base_ai)]:
        val[nm] = {'spearman': float(spearmanr(v, spec).statistic), 'ci95': boot(v, spec)}
    from scipy.optimize import nnls
    oof, W = np.zeros(len(y)), []
    for tr, te in GroupKFold(n_splits=5).split(np.zeros(len(y)), y, tmpl):
        w, _ = nnls(facets[tr], spec[tr] / 3.0)
        W.append(w); oof[te] = facets[te] @ w
    val['AICS (out-of-fold calibrated)'] = {
        'spearman': float(spearmanr(oof, spec).statistic), 'ci95': boot(oof, spec),
        'mean_weights': dict(zip('ARFVC', np.round(np.mean(W, 0), 3).tolist()))}
    val['facet_rho'] = {k: float(spearmanr(facets[:, i], spec).statistic)
                        for i, k in enumerate('ARFVC')}
    save('validation', val)
    for k, v in val.items():
        if isinstance(v, dict) and 'spearman' in v:
            print(f"  {k:32s} rho={v['spearman']:+.3f} CI={np.round(v['ci95'],3).tolist()}")
    print('  facet rho:', {k: round(v, 3) for k, v in val['facet_rho'].items()})


def stage_application():
    eq = np.array([A.aics(t) for t in texts])
    years = np.array([d[:4] for d in dates])
    app = {}

    naive, adj = {}, {}
    for yr in sorted(set(years.tolist())):
        m = years == yr
        naive[yr] = float(np.mean(y[m] == 'HEDGE'))
        seen, keep = set(), []
        for i in np.where(m)[0]:
            if tmpl[i] in seen:
                continue
            seen.add(tmpl[i]); keep.append(i)
        adj[yr] = float(np.mean(y[keep] == 'HEDGE'))
    app['hedge_share_naive'] = naive
    app['hedge_share_detemplated'] = adj

    tc = np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])
    hg = y == 'HEDGE'
    app['HHA_overall'] = float(eq[tc].mean() - eq[hg].mean())
    app['HHA_p'] = float(mannwhitneyu(eq[tc], eq[hg], alternative='greater').pvalue)
    app['spec_tool_mean'] = float(spec[tc].mean())
    app['spec_hedge_mean'] = float(spec[hg].mean())
    app['spec_HHA'] = float(spec[tc].mean() - spec[hg].mean())
    app['spec_HHA_p'] = float(mannwhitneyu(spec[tc], spec[hg], alternative='greater').pvalue)

    def boot_diff(a, b, n=5000, seed=0):
        rng = np.random.default_rng(seed)
        d = [a[rng.integers(0, len(a), len(a))].mean() - b[rng.integers(0, len(b), len(b))].mean()
             for _ in range(n)]
        return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]
    app['HHA_ci95'] = boot_diff(eq[tc], eq[hg])

    pre, post = dates < ENFORCEMENT, dates >= ENFORCEMENT
    app['n_pre'], app['n_post'] = int(pre.sum()), int(post.sum())
    app['composition_pre'] = dict(Counter(y[pre].tolist()))
    app['composition_post'] = dict(Counter(y[post].tolist()))
    # composition-controlled: compare AICS *within* the tool-claim class only
    a, b = eq[post & tc], eq[pre & tc]
    app['n_toolclaim_pre'], app['n_toolclaim_post'] = int(len(b)), int(len(a))
    app['aics_toolclaim_pre'] = float(b.mean())
    app['aics_toolclaim_post'] = float(a.mean())
    app['aics_toolclaim_diff'] = float(a.mean() - b.mean())
    app['aics_toolclaim_diff_ci95'] = boot_diff(a, b)
    app['aics_toolclaim_p'] = float(mannwhitneyu(a, b, alternative='two-sided').pvalue)
    app['templated_share_pre'] = cluster_stats(tmpl[pre])['templated_share']
    app['templated_share_post'] = cluster_stats(tmpl[post])['templated_share']

    # cross-filer template families
    reuse = defaultdict(set)
    for t, c in zip(tmpl, ciks):
        reuse[int(t)].add(c)
    fams = sorted(((len(v), int(k)) for k, v in reuse.items() if len(v) > 1), reverse=True)
    app['top_families'] = [
        {'n_filers': n, 'size': int((tmpl == t).sum()),
         'label': Counter(y[tmpl == t].tolist()).most_common(1)[0][0],
         'example': texts[int(np.where(tmpl == t)[0][0])][:150]}
        for n, t in fams[:5]]
    save('application', app)
    print(json.dumps({k: v for k, v in app.items()
                      if not isinstance(v, (dict, list))}, indent=1))


if __name__ == '__main__':
    {'corpus': stage_corpus, 'protocol': stage_protocol, 'ablation': stage_ablation,
     'sensitivity': stage_sensitivity, 'validation': stage_validation,
     'leakage': stage_leakage,
     'application': stage_application}[sys.argv[1]]()
