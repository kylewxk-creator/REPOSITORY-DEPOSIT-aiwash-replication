"""
TemplateGuard -- near-duplicate template detection for regulatory disclosure.

Disclosure text propagates: a risk factor drafted by one law firm reappears,
lightly edited, across dozens of filers and across successive filing years.
TemplateGuard recovers those families so that (i) evaluation splits can be made
template-disjoint and (ii) prevalence counts can be de-templated.

Pipeline
--------
1. normalise a segment (case-fold, strip punctuation, collapse entity-specific
   tokens such as "Adviser"/"Advisor"/"Company"/"Fund" to a single placeholder)
2. build word k-shingles
3. MinHash signature (num_perm permutations)
4. LSH query at Jaccard threshold tau -> candidate edges
5. connected components of the candidate graph -> template clusters
"""
import re
from datasketch import MinHash, MinHashLSH

ENTITY_TOKENS = [
    'adviser', 'advisor', 'company', 'fund', 'funds', 'portfolios', 'portfolio',
    'manager', 'trust', 'investment', 'investments', 'sub-adviser', 'partner',
    'general', 'firm', 'registrant', 'issuer',
]
ENTITY_RE = re.compile(r'\b(' + '|'.join(ENTITY_TOKENS) + r')\b')
NUM_RE = re.compile(r'\d+')
NONWORD_RE = re.compile(r'[^a-z0-9 ]+')


def normalise(text):
    t = text.lower()
    t = NONWORD_RE.sub(' ', t)
    t = ENTITY_RE.sub('<ent>', t)
    t = NUM_RE.sub('<num>', t)
    return re.sub(r'\s+', ' ', t).strip()


def shingles(text, k=5):
    w = normalise(text).split()
    if len(w) < k:
        return {' '.join(w)} if w else {'<empty>'}
    return {' '.join(w[i:i + k]) for i in range(len(w) - k + 1)}


def signature(text, k=5, num_perm=128):
    m = MinHash(num_perm=num_perm)
    for s in shingles(text, k):
        m.update(s.encode('utf8'))
    return m


def cluster(texts, tau=0.5, k=5, num_perm=128):
    """Return a list of cluster ids, one per input text."""
    sigs = [signature(t, k, num_perm) for t in texts]
    lsh = MinHashLSH(threshold=tau, num_perm=num_perm)
    for i, m in enumerate(sigs):
        lsh.insert(str(i), m)

    parent = list(range(len(texts)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[max(ra, rb)] = min(ra, rb)

    for i, m in enumerate(sigs):
        for j in lsh.query(m):
            j = int(j)
            if j != i:
                union(i, j)

    roots = {}
    out = []
    for i in range(len(texts)):
        r = find(i)
        if r not in roots:
            roots[r] = len(roots)
        out.append(roots[r])
    return out


def jaccard(a, b, k=5):
    sa, sb = shingles(a, k), shingles(b, k)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def cluster_stats(labels):
    from collections import Counter
    c = Counter(labels)
    sizes = sorted(c.values(), reverse=True)
    n = len(labels)
    return {
        'n_segments': n,
        'n_clusters': len(c),
        'n_singletons': sum(1 for v in sizes if v == 1),
        'largest': sizes[0] if sizes else 0,
        'top5': sizes[:5],
        'templated_share': 1.0 - len(c) / n if n else 0.0,
    }
