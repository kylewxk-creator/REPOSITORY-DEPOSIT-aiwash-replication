"""Two additional analyses.

A. Novel-subset estimator.  A template-disjoint split is not always available:
   the corpus may already be fixed, or an experiment may already have been run.
   We test whether evaluating a randomly-split model on the subset of test
   items that have no near-duplicate in training recovers the score that a
   template-disjoint split would have produced.  If it does, any existing
   random-split experiment can be audited after the fact without re-running it.

B. Template diffusion.  Families carry timestamps and registrant identities,
   so a template can be tracked as it spreads.  We measure diffusion breadth
   and lifespan and test whether more widely diffused language is less
   specific.
"""
import json, os, sys, warnings
import numpy as np
from collections import defaultdict, Counter
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')

import pipeline as P
import aics as A
from templateguard import shingles
from sklearn.metrics import f1_score, accuracy_score
from scipy.stats import spearmanr

texts, y, spec = P.texts, P.y, P.spec
ciks, tmpl, dates, docs = P.ciks, P.tmpl, P.dates, P.docs
SEEDS, KSH = P.SEEDS, P.KSH
SH = [shingles(t, KSH) for t in texts]
THR = 0.4


def max_sim(i, train_idx):
    a = SH[i]
    best = 0.0
    for j in train_idx:
        b = SH[j]
        u = len(a | b)
        if u:
            v = len(a & b) / u
            if v > best:
                best = v
    return best


# --------------------------------------------------------------------------
# A. novel-subset estimator
# --------------------------------------------------------------------------
def novel_subset_estimator():
    models = [k for k in P.make_models(0) if k != 'Majority class']
    # similarity depends only on the split, so cache it once per seed
    SIM = {}
    for sd in SEEDS:
        v = np.zeros(len(y))
        for tr, te in P.splits('random', seed=sd):
            for i in te:
                v[i] = max_sim(i, tr)
        SIM[sd] = v
    rows = {}
    for name in models:
        rnd_f1, rnd_acc, nov_f1, nov_acc, share = [], [], [], [], []
        for sd in SEEDS:
            yt, yp, nd = [], [], []
            for tr, te in P.splits('random', seed=sd):
                m = P.make_models(sd)[name]()
                m.fit([texts[i] for i in tr], y[tr])
                pr = m.predict([texts[i] for i in te])
                for i, p in zip(te, pr):
                    yt.append(y[i]); yp.append(p)
                    nd.append(SIM[sd][i] >= THR)
            yt = np.array(yt); yp = np.array(yp); nd = np.array(nd)
            rnd_f1.append(f1_score(yt, yp, average='macro', zero_division=0))
            rnd_acc.append(accuracy_score(yt, yp))
            nov_f1.append(f1_score(yt[~nd], yp[~nd], average='macro', zero_division=0))
            nov_acc.append(accuracy_score(yt[~nd], yp[~nd]))
            share.append(float(nd.mean()))
        # actual template-disjoint scores
        t_f1, t_acc = [], []
        for sd in SEEDS:
            f1s, accs = [], []
            for tr, te in P.splits('template', seed=sd):
                m = P.make_models(sd)[name]()
                m.fit([texts[i] for i in tr], y[tr])
                pr = m.predict([texts[i] for i in te])
                f1s.append(f1_score(y[te], pr, average='macro', zero_division=0))
                accs.append(accuracy_score(y[te], pr))
            t_f1.append(np.mean(f1s)); t_acc.append(np.mean(accs))
        rows[name] = {
            'random_f1': float(np.mean(rnd_f1)), 'random_acc': float(np.mean(rnd_acc)),
            'novel_subset_f1': float(np.mean(nov_f1)), 'novel_subset_acc': float(np.mean(nov_acc)),
            'template_f1': float(np.mean(t_f1)), 'template_acc': float(np.mean(t_acc)),
            'near_dup_share': float(np.mean(share)),
        }
        r = rows[name]
        r['err_uncorrected_f1'] = r['random_f1'] - r['template_f1']
        r['err_corrected_f1'] = r['novel_subset_f1'] - r['template_f1']
        r['err_uncorrected_acc'] = r['random_acc'] - r['template_acc']
        r['err_corrected_acc'] = r['novel_subset_acc'] - r['template_acc']
        print(f"  {name:24s} rand={r['random_f1']:.3f} novel={r['novel_subset_f1']:.3f} "
              f"tmpl={r['template_f1']:.3f} | err raw={r['err_uncorrected_f1']:+.3f} "
              f"corr={r['err_corrected_f1']:+.3f}")

    eu = np.array([rows[m]['err_uncorrected_f1'] for m in rows])
    ec = np.array([rows[m]['err_corrected_f1'] for m in rows])
    eua = np.array([rows[m]['err_uncorrected_acc'] for m in rows])
    eca = np.array([rows[m]['err_corrected_acc'] for m in rows])
    summ = {
        'n_models': len(rows),
        'mae_uncorrected_f1': float(np.abs(eu).mean()),
        'mae_corrected_f1': float(np.abs(ec).mean()),
        'bias_uncorrected_f1': float(eu.mean()), 'bias_corrected_f1': float(ec.mean()),
        'mae_uncorrected_acc': float(np.abs(eua).mean()),
        'mae_corrected_acc': float(np.abs(eca).mean()),
        'bias_uncorrected_acc': float(eua.mean()), 'bias_corrected_acc': float(eca.mean()),
        'rank_corr_novel_vs_template': float(
            spearmanr([rows[m]['novel_subset_f1'] for m in rows],
                      [rows[m]['template_f1'] for m in rows]).statistic),
        'rank_corr_random_vs_template': float(
            spearmanr([rows[m]['random_f1'] for m in rows],
                      [rows[m]['template_f1'] for m in rows]).statistic),
    }
    print('\n  summary:', json.dumps(summ, indent=1))
    P.save('novel_subset', {'per_model': rows, 'summary': summ})
    return rows, summ


# --------------------------------------------------------------------------
# B. template diffusion
# --------------------------------------------------------------------------
def diffusion():
    eq = np.array([A.aics(t) for t in texts])
    fam = defaultdict(list)
    for i, t in enumerate(tmpl):
        fam[int(t)].append(i)

    recs = []
    for f, idx in fam.items():
        ds = sorted(dates[i] for i in idx)
        regs = {ciks[i] for i in idx}
        d0 = date(*map(int, ds[0].split('-')))
        d1 = date(*map(int, ds[-1].split('-')))
        recs.append({
            'family': f, 'size': len(idx), 'n_registrants': len(regs),
            'first': ds[0], 'last': ds[-1], 'span_days': (d1 - d0).days,
            'mean_aics': float(eq[idx].mean()),
            'mean_spec': float(spec[idx].mean()),
            'label': Counter(y[idx].tolist()).most_common(1)[0][0],
        })

    multi = [r for r in recs if r['size'] >= 2]
    cross = [r for r in recs if r['n_registrants'] >= 2]
    print(f'  families={len(recs)} multi-member={len(multi)} cross-filer={len(cross)}')

    # does wider diffusion go with less specific language?
    size = np.array([r['size'] for r in recs], float)
    nreg = np.array([r['n_registrants'] for r in recs], float)
    aic = np.array([r['mean_aics'] for r in recs])
    sp = np.array([r['mean_spec'] for r in recs])
    out = {
        'n_families': len(recs), 'n_multi': len(multi), 'n_cross': len(cross),
        'rho_size_aics': float(spearmanr(size, aic).statistic),
        'rho_registrants_aics': float(spearmanr(nreg, aic).statistic),
        'rho_size_spec': float(spearmanr(size, sp).statistic),
        'rho_registrants_spec': float(spearmanr(nreg, sp).statistic),
    }

    def boot_rho(x, yy, n=4000, seed=0):
        rng = np.random.default_rng(seed)
        v = [spearmanr(x[i], yy[i]).statistic
             for i in (rng.integers(0, len(x), len(x)) for _ in range(n))]
        return [float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))]
    out['ci_rho_registrants_aics'] = boot_rho(nreg, aic)
    out['ci_rho_registrants_spec'] = boot_rho(nreg, sp)

    # segment-level: AICS of segments in cross-filer families vs the rest
    incross = np.array([len({ciks[j] for j in fam[int(t)]}) >= 2 for t in tmpl])
    out['aics_in_crossfiler'] = float(eq[incross].mean())
    out['aics_not_crossfiler'] = float(eq[~incross].mean())
    out['spec_in_crossfiler'] = float(spec[incross].mean())
    out['spec_not_crossfiler'] = float(spec[~incross].mean())
    out['n_in_crossfiler'] = int(incross.sum())

    # diffusion breadth and lifespan of the cross-filer families
    out['cross_family_stats'] = {
        'median_registrants': float(np.median([r['n_registrants'] for r in cross])),
        'max_registrants': int(max(r['n_registrants'] for r in cross)),
        'median_span_days': float(np.median([r['span_days'] for r in cross])),
        'max_span_days': int(max(r['span_days'] for r in cross)),
        'label_mix': dict(Counter(r['label'] for r in cross)),
    }
    out['top_families'] = sorted(
        [{k: r[k] for k in ('n_registrants', 'size', 'span_days', 'first', 'last',
                            'label', 'mean_aics')} for r in cross],
        key=lambda r: (-r['n_registrants'], -r['size']))[:8]

    print('  ' + json.dumps({k: v for k, v in out.items()
                             if not isinstance(v, (dict, list))}, indent=1))
    print('  cross-family stats:', out['cross_family_stats'])
    for r in out['top_families'][:5]:
        print(f"    {r['n_registrants']} filers, n={r['size']}, "
              f"{r['first']}..{r['last']} ({r['span_days']}d), {r['label']}, "
              f"AICS={r['mean_aics']:.3f}")
    P.save('diffusion', out)
    return out


if __name__ == '__main__':
    w = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if w in ('all', 'novel'):
        print('=== A. novel-subset estimator ===')
        novel_subset_estimator()
    if w in ('all', 'diffusion'):
        print('\n=== B. template diffusion ===')
        diffusion()
