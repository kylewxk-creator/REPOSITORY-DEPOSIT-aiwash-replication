"""Full experimental pipeline for the AI-washing disclosure study."""
import json, os, sys, warnings
import numpy as np
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(__file__))
warnings.filterwarnings('ignore')

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import ComplementNB
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.metrics import f1_score, accuracy_score, classification_report
from sklearn.dummy import DummyClassifier
from scipy.stats import spearmanr, pearsonr, mannwhitneyu
from scipy.sparse import hstack, csr_matrix

import aics as A
from templateguard import cluster, cluster_stats, jaccard

ROOT = os.path.join(os.path.dirname(__file__), '..')
DATA = os.path.join(ROOT, 'data', 'segments_labeled.jsonl')
RES = os.path.join(ROOT, 'results')
os.makedirs(RES, exist_ok=True)

CLASSES = ['TOOL_CAP', 'TOOL_PROC', 'EXPOSURE', 'HEDGE', 'BOIL']
ENFORCEMENT = '2024-03-18'   # SEC first AI-washing actions
SEEDS = [0, 1, 2]

# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------
segs = [json.loads(l) for l in open(DATA)]
texts = [s['text'] for s in segs]
y = np.array([s['label'] for s in segs])
spec = np.array([s['spec'] for s in segs])
docs = np.array([s['doc_id'] for s in segs])
ciks = np.array([s['cik'] for s in segs])
dates = np.array([s['filed'] for s in segs])

tmpl = np.array(cluster(texts, tau=0.5, k=5, num_perm=128))
for s, t in zip(segs, tmpl):
    s['template_id'] = int(t)

results = {}

# ---------------------------------------------------------------------------
# 0. corpus description
# ---------------------------------------------------------------------------
st = cluster_stats(tmpl)
results['corpus'] = {
    'n_segments': len(segs),
    'n_documents': len(set(docs)),
    'n_filers': len(set(ciks)),
    'n_forms': len(set(s['form'] for s in segs)),
    'year_range': [min(dates)[:4], max(dates)[:4]],
    'class_dist': dict(Counter(y.tolist())),
    'spec_dist': {str(k): int(v) for k, v in sorted(Counter(spec.tolist()).items())},
    'median_words': int(np.median([s['n_words'] for s in segs])),
    'template_stats': st,
    'exact_dup_rate': float(np.mean([s['exact_dup'] for s in segs])),
}
print('CORPUS', json.dumps(results['corpus'], indent=1)[:700])

# ---------------------------------------------------------------------------
# model zoo
# ---------------------------------------------------------------------------
_FEAT_CACHE = {}


def struct_matrix(txts):
    out = []
    for t in txts:
        v = _FEAT_CACHE.get(t)
        if v is None:
            v = A.feature_vector(t)
            _FEAT_CACHE[t] = v
        out.append(v)
    return np.array(out)


class Fusion:
    """Early fusion: TF-IDF lexical channel concatenated with the AICS
    structural channel, the latter scaled by alpha."""
    def __init__(self, C=4.0, ngram=(1, 2), max_features=8000, use_struct=True,
                 use_tfidf=True, struct_keep=None, alpha=1.0, seed=0):
        self.C, self.ngram, self.max_features = C, ngram, max_features
        self.use_struct, self.use_tfidf = use_struct, use_tfidf
        self.struct_keep, self.alpha, self.seed = struct_keep, alpha, seed

    def _struct(self, txts):
        M = struct_matrix(txts)
        if self.struct_keep is not None:
            idx = [A.FEATURE_NAMES.index(k) for k in self.struct_keep]
            M = M[:, idx]
        return M

    def fit(self, txts, yy):
        blocks = []
        if self.use_tfidf:
            self.tf = TfidfVectorizer(ngram_range=self.ngram, min_df=2,
                                      sublinear_tf=True, max_features=self.max_features)
            blocks.append(self.tf.fit_transform(txts))
        if self.use_struct:
            M = self._struct(txts)
            self.sc = StandardScaler().fit(M)
            blocks.append(csr_matrix(self.sc.transform(M) * self.alpha))
        X = hstack(blocks).tocsr() if len(blocks) > 1 else blocks[0]
        self.clf = LogisticRegression(C=self.C, max_iter=4000,
                                      class_weight='balanced', random_state=self.seed)
        self.clf.fit(X, yy)
        return self

    def _X(self, txts):
        blocks = []
        if self.use_tfidf:
            blocks.append(self.tf.transform(txts))
        if self.use_struct:
            blocks.append(csr_matrix(self.sc.transform(self._struct(txts)) * self.alpha))
        return hstack(blocks).tocsr() if len(blocks) > 1 else blocks[0]

    def predict(self, txts):
        return self.clf.predict(self._X(txts))


class Hybrid:
    """AIDT-Hybrid: stacked fusion of a lexical channel, a character channel
    and the AICS structural channel, combined by a logistic meta-learner
    trained on out-of-fold predictions inside the training split."""
    def __init__(self, seed=0, use_struct=True, use_tfidf=True,
                 struct_keep=None, C=4.0, ngram=(1, 2), alpha=1.0,
                 max_features=8000):
        self.seed, self.use_struct, self.use_tfidf = seed, use_struct, use_tfidf
        self.struct_keep, self.C, self.ngram = struct_keep, C, ngram
        self.alpha, self.max_features = alpha, max_features

    def _struct_pipe(self):
        keep = self.struct_keep
        def _f(txts):
            M = struct_matrix(txts)
            if keep is not None:
                idx = [A.FEATURE_NAMES.index(k) for k in keep]
                M = M[:, idx]
            return M
        return Pipeline([('f', FunctionTransformer(_f, validate=False)),
                         ('s', StandardScaler()),
                         ('c', GradientBoostingClassifier(n_estimators=120, max_depth=2,
                                                         random_state=self.seed))])

    def fit(self, txts, yy):
        ests = []
        if self.use_tfidf:
            ests.append(('lex', Pipeline([
                ('v', TfidfVectorizer(ngram_range=self.ngram, min_df=2,
                                      sublinear_tf=True, max_features=self.max_features)),
                ('c', LogisticRegression(C=self.C, max_iter=4000,
                                         class_weight='balanced',
                                         random_state=self.seed))])))
            ests.append(('chr', Pipeline([
                ('v', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5),
                                      min_df=2, sublinear_tf=True, max_features=20000)),
                ('c', LogisticRegression(C=self.C, max_iter=4000,
                                         class_weight='balanced',
                                         random_state=self.seed))])))
        if self.use_struct:
            ests.append(('aics', self._struct_pipe()))
        if len(ests) == 1:
            self.m = ests[0][1]
        else:
            from sklearn.ensemble import StackingClassifier
            self.m = StackingClassifier(
                estimators=ests,
                final_estimator=LogisticRegression(max_iter=4000,
                                                   class_weight='balanced',
                                                   random_state=self.seed),
                cv=3, stack_method='predict_proba', n_jobs=1)
        self.m.fit(txts, yy)
        return self

    def predict(self, txts):
        return self.m.predict(txts)


class RuleBaseline:
    """Transparent keyword/regex rule set -- the kind of instrument used in
    prior keyword-count disclosure studies."""
    def fit(self, txts, yy):
        return self

    def predict(self, txts):
        import re
        out = []
        for t in txts:
            low = ' ' + t.lower() + ' '
            ai = any(k in low for k in A.AI_CORE)
            if not ai:
                out.append('BOIL'); continue
            if any(k in low for k in ['risk', 'no assurance', 'adverse', 'may not',
                                      'cannot', 'unpredictable', 'inaccura', 'fail']):
                out.append('HEDGE'); continue
            if any(k in low for k in ['index', 'net assets', 'invest at least',
                                      'companies involved', 'exposure to', 'holdings']):
                out.append('EXPOSURE'); continue
            if any(k in low for k in ['productivity', 'routine tasks', 'operational',
                                      'workflows', 'administrative']):
                out.append('TOOL_PROC'); continue
            out.append('TOOL_CAP')
        return np.array(out)


def make_models(seed=0):
    return {
        'Majority': lambda: DummyClassifier(strategy='most_frequent'),
        'KeywordRules': lambda: RuleBaseline(),
        'TFIDF+ComplementNB': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', ComplementNB())]),
        'TFIDF+LogReg': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', LogisticRegression(max_iter=4000, class_weight='balanced',
                                     random_state=seed))]),
        'TFIDF+LinearSVC': lambda: Pipeline([
            ('v', TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ('c', LinearSVC(class_weight='balanced', random_state=seed))]),
        'CharTFIDF+LinearSVC': lambda: Pipeline([
            ('v', TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 5), min_df=2,
                                  sublinear_tf=True, max_features=20000)),
            ('c', LinearSVC(class_weight='balanced', random_state=seed))]),
        'AICS-struct+LogReg': lambda: Hybrid(use_tfidf=False, seed=seed),
        'AICS-struct+GBM': lambda: Pipeline([
            ('f', FunctionTransformer(struct_matrix, validate=False)),
            ('c', GradientBoostingClassifier(random_state=seed))]),
        'AICS-struct+RF': lambda: Pipeline([
            ('f', FunctionTransformer(struct_matrix, validate=False)),
            ('c', RandomForestClassifier(n_estimators=400, class_weight='balanced',
                                         random_state=seed))]),
        'AIDT-Hybrid (ours)': lambda: Hybrid(seed=seed),
    }


def splits(scheme, n_splits=5, seed=0):
    if scheme == 'random':
        cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(cv.split(np.zeros(len(y)), y))
    groups = docs if scheme == 'document' else tmpl
    cv = GroupKFold(n_splits=n_splits)
    return list(cv.split(np.zeros(len(y)), y, groups))


def evaluate(model_fn, scheme, seed=0):
    f1s, accs = [], []
    for tr, te in splits(scheme, seed=seed):
        m = model_fn()
        Xtr = [texts[i] for i in tr]; Xte = [texts[i] for i in te]
        m.fit(Xtr, y[tr])
        p = m.predict(Xte)
        f1s.append(f1_score(y[te], p, average='macro', zero_division=0))
        accs.append(accuracy_score(y[te], p))
    return float(np.mean(f1s)), float(np.std(f1s)), float(np.mean(accs))


# ---------------------------------------------------------------------------
# E1 + E2  leakage protocol and model comparison
# ---------------------------------------------------------------------------
print('\n=== E1/E2: evaluation protocol x model ===')
table = {}
for name in make_models(0):
    row = {}
    for scheme in ['random', 'document', 'template']:
        f1s = []
        for sd in SEEDS:
            f1, _, acc = evaluate(make_models(sd)[name], scheme, seed=sd)
            f1s.append(f1)
        row[scheme] = {'macro_f1': float(np.mean(f1s)),
                       'sd': float(np.std(f1s))}
    row['optimism_gap'] = row['random']['macro_f1'] - row['template']['macro_f1']
    table[name] = row
    print(f"{name:22s} rand={row['random']['macro_f1']:.3f} "
          f"doc={row['document']['macro_f1']:.3f} "
          f"tmpl={row['template']['macro_f1']:.3f} "
          f"gap={row['optimism_gap']:+.3f}")
results['protocol_x_model'] = table
with open(os.path.join(RES, 'protocol_table.json'), 'w') as f:
    json.dump(table, f, indent=1)

# per-class report for the proposed model under the strict protocol
preds_all, true_all = [], []
for tr, te in splits('template', seed=0):
    m = Hybrid(seed=0).fit([texts[i] for i in tr], y[tr])
    preds_all += list(m.predict([texts[i] for i in te])); true_all += list(y[te])
results['per_class_template'] = classification_report(
    true_all, preds_all, output_dict=True, zero_division=0)
print('\nper-class (template-disjoint):')
print(classification_report(true_all, preds_all, zero_division=0))

# ---------------------------------------------------------------------------
# E3  ablations
# ---------------------------------------------------------------------------
print('=== E3: ablations (template-disjoint) ===')
GROUPS = {
    'aics_facets': ['aics_A', 'aics_R', 'aics_F', 'aics_V', 'aics_C', 'aics'],
    'lexical_cues': ['risk_cue', 'theme_cue', 'ops_cue', 'hedge_cue', 'assert_cue'],
    'agency': ['first_person', 'third_party'],
    'surface': ['n_words', 'n_numerals', 'ai_term', 'defined_term'],
}
abl = {}
full = [f1 for f1 in [evaluate(lambda: Hybrid(seed=sd), 'template', sd)[0] for sd in SEEDS]]
abl['full'] = {'macro_f1': float(np.mean(full)), 'sd': float(np.std(full))}
for g, keys in GROUPS.items():
    keep = [k for k in A.FEATURE_NAMES if k not in keys]
    v = [evaluate(lambda sd=sd, keep=keep: Hybrid(struct_keep=keep, seed=sd),
                  'template', sd)[0] for sd in SEEDS]
    abl['minus_' + g] = {'macro_f1': float(np.mean(v)), 'sd': float(np.std(v)),
                         'delta': float(np.mean(v) - np.mean(full))}
v = [evaluate(lambda sd=sd: Hybrid(use_struct=False, seed=sd), 'template', sd)[0] for sd in SEEDS]
abl['tfidf_only'] = {'macro_f1': float(np.mean(v)), 'sd': float(np.std(v)),
                     'delta': float(np.mean(v) - np.mean(full))}
v = [evaluate(lambda sd=sd: Hybrid(use_tfidf=False, seed=sd), 'template', sd)[0] for sd in SEEDS]
abl['struct_only'] = {'macro_f1': float(np.mean(v)), 'sd': float(np.std(v)),
                      'delta': float(np.mean(v) - np.mean(full))}
for k, r in abl.items():
    print(f"  {k:22s} {r['macro_f1']:.3f}  d={r.get('delta', 0):+.3f}")
results['ablation'] = abl

# single-facet leave-one-out inside the AICS channel
facet_abl = {}
fac_keys = {'A': 'aics_A', 'R': 'aics_R', 'F': 'aics_F', 'V': 'aics_V', 'C': 'aics_C'}
for f, key in fac_keys.items():
    keep = [k for k in A.FEATURE_NAMES if k != key]
    v = [evaluate(lambda sd=sd, keep=keep: Hybrid(struct_keep=keep, seed=sd),
                  'template', sd)[0] for sd in SEEDS]
    facet_abl['minus_' + f] = {'macro_f1': float(np.mean(v)),
                               'delta': float(np.mean(v) - np.mean(full))}
results['facet_ablation'] = facet_abl
print('  facet LOO:', {k: round(v['delta'], 3) for k, v in facet_abl.items()})

# ---------------------------------------------------------------------------
# E4  sensitivity
# ---------------------------------------------------------------------------
print('=== E4: sensitivity ===')
sens = {'tau': {}, 'shingle_k': {}, 'ngram': {}, 'C': {}}
for tau in [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
    lab = np.array(cluster(texts, tau=tau, k=5))
    g = lab
    cv = GroupKFold(n_splits=5)
    f1s = []
    for sd in SEEDS[:3]:
        vals = []
        for tr, te in cv.split(np.zeros(len(y)), y, g):
            m = Hybrid(seed=sd).fit([texts[i] for i in tr], y[tr])
            vals.append(f1_score(y[te], m.predict([texts[i] for i in te]),
                                 average='macro', zero_division=0))
        f1s.append(np.mean(vals))
    sens['tau'][str(tau)] = {'macro_f1': float(np.mean(f1s)),
                             'n_clusters': int(len(set(lab.tolist()))),
                             'templated_share': cluster_stats(lab)['templated_share']}
for k in [3, 4, 5, 6, 8]:
    lab = np.array(cluster(texts, tau=0.5, k=k))
    sens['shingle_k'][str(k)] = {'n_clusters': int(len(set(lab.tolist()))),
                                 'templated_share': cluster_stats(lab)['templated_share']}
for ng in [(1, 1), (1, 2), (1, 3)]:
    v = [evaluate(lambda sd=sd, ng=ng: Hybrid(ngram=ng, seed=sd), 'template', sd)[0]
         for sd in SEEDS[:3]]
    sens['ngram'][str(ng)] = float(np.mean(v))
for C in [0.25, 0.5, 1.0, 2.0, 4.0, 8.0]:
    v = [evaluate(lambda sd=sd, C=C: Hybrid(C=C, seed=sd), 'template', sd)[0]
         for sd in SEEDS[:3]]
    sens['C'][str(C)] = float(np.mean(v))
results['sensitivity'] = sens
print('  tau  ->', {k: round(v['macro_f1'], 3) for k, v in sens['tau'].items()})
print('  ngram->', {k: round(v, 3) for k, v in sens['ngram'].items()})
print('  C    ->', {k: round(v, 3) for k, v in sens['C'].items()})

# ---------------------------------------------------------------------------
# E5  AICS validation against expert specificity ratings
# ---------------------------------------------------------------------------
print('=== E5: AICS construct validation ===')
eq = np.array([A.aics(t) for t in texts])
facets = np.array([[A.facet_scores(t)[k] for k in 'ARFVC'] for t in texts])
base_len = np.array([len(t.split()) for t in texts], float)
base_num = np.array([len(A.NUM_RE.findall(t)) for t in texts], float)
base_ai = np.array([sum(k in ' ' + t.lower() + ' ' for k in A.AI_CORE) for t in texts], float)

def boot_rho(x, yv, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    vals = [spearmanr(x[i], yv[i]).statistic
            for i in (rng.integers(0, len(x), len(x)) for _ in range(n))]
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))

val = {}
for nm, v in [('AICS (equal weights)', eq), ('segment length', base_len),
              ('numeral count', base_num), ('AI-term count', base_ai)]:
    r = spearmanr(v, spec).statistic
    lo, hi = boot_rho(v, spec)
    val[nm] = {'spearman': float(r), 'ci95': [lo, hi]}
    print(f'  {nm:22s} rho={r:+.3f}  CI=[{lo:+.3f},{hi:+.3f}]')

# out-of-fold calibrated weights (no in-sample tuning)
from scipy.optimize import nnls
oof = np.zeros(len(y))
cv = GroupKFold(n_splits=5)
Wlist = []
for tr, te in cv.split(np.zeros(len(y)), y, tmpl):
    w, _ = nnls(facets[tr], spec[tr] / 3.0)
    Wlist.append(w)
    oof[te] = facets[te] @ w
r = spearmanr(oof, spec).statistic
lo, hi = boot_rho(oof, spec)
val['AICS (out-of-fold calibrated)'] = {'spearman': float(r), 'ci95': [lo, hi],
                                        'mean_weights': dict(zip('ARFVC', np.round(np.mean(Wlist, 0), 3).tolist()))}
print(f"  AICS calibrated (OOF)  rho={r:+.3f}  CI=[{lo:+.3f},{hi:+.3f}]  w={val['AICS (out-of-fold calibrated)']['mean_weights']}")
results['aics_validation'] = val
results['aics_by_class'] = {c: {'mean': float(eq[y == c].mean()),
                                'sd': float(eq[y == c].std()),
                                'n': int((y == c).sum())} for c in CLASSES}

# ---------------------------------------------------------------------------
# E6  application: de-templated prevalence, asymmetry, enforcement window
# ---------------------------------------------------------------------------
print('=== E6: application analyses ===')
years = np.array([d[:4] for d in dates])
app = {}

# (a) naive vs de-templated share of hedging language by year
naive, adjusted = {}, {}
for yr in sorted(set(years.tolist())):
    m = years == yr
    naive[yr] = float(np.mean(y[m] == 'HEDGE'))
    seen, keep = set(), []
    for i in np.where(m)[0]:
        if tmpl[i] in seen:
            continue
        seen.add(tmpl[i]); keep.append(i)
    adjusted[yr] = float(np.mean(y[keep] == 'HEDGE')) if keep else float('nan')
app['hedge_share_naive'] = naive
app['hedge_share_detemplated'] = adjusted

# (b) hype-hedge asymmetry index: AICS(tool claims) - AICS(hedges)
def hha(mask):
    a = eq[mask & np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])]
    b = eq[mask & (y == 'HEDGE')]
    if len(a) == 0 or len(b) == 0:
        return None
    return float(a.mean() - b.mean())

app['HHA_overall'] = hha(np.ones(len(y), bool))
u = mannwhitneyu(eq[np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])], eq[y == 'HEDGE'],
                 alternative='greater')
app['HHA_mannwhitney_p'] = float(u.pvalue)

pre = dates < ENFORCEMENT
post = dates >= ENFORCEMENT
app['n_pre'], app['n_post'] = int(pre.sum()), int(post.sum())
for nm, m in [('pre', pre), ('post', post)]:
    app[f'HHA_{nm}'] = hha(m)
    app[f'aics_toolclaims_{nm}'] = float(eq[m & np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])].mean()) \
        if (m & np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])).sum() else None
    app[f'aics_hedge_{nm}'] = float(eq[m & (y == 'HEDGE')].mean()) \
        if (m & (y == 'HEDGE')).sum() else None
    app[f'hedge_share_{nm}'] = float(np.mean(y[m] == 'HEDGE'))
    app[f'toolclaim_share_{nm}'] = float(np.mean(np.isin(y[m], ['TOOL_CAP', 'TOOL_PROC'])))
    app[f'templated_share_{nm}'] = cluster_stats(tmpl[m])['templated_share']

# (c) composition-controlled comparison: within tool-claim segments and within
# hedge segments separately, so that the period contrast is not driven by the
# changing mix of document types in the sample.
def boot_mean_diff(a, b, n=5000, seed=0):
    rng = np.random.default_rng(seed)
    d = [a[rng.integers(0, len(a), len(a))].mean() - b[rng.integers(0, len(b), len(b))].mean()
         for _ in range(n)]
    return float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))

tc = np.isin(y, ['TOOL_CAP', 'TOOL_PROC'])
a, b = eq[post & tc], eq[pre & tc]
app['aics_toolclaim_post_minus_pre'] = float(a.mean() - b.mean())
app['aics_toolclaim_post_minus_pre_ci'] = list(boot_mean_diff(a, b))
app['n_toolclaim_pre'], app['n_toolclaim_post'] = int((pre & tc).sum()), int((post & tc).sum())
app['toolclaim_pre_post_mwu_p'] = float(mannwhitneyu(a, b, alternative='two-sided').pvalue)

# (d) cross-filer template reuse
reuse = defaultdict(set)
for t, c in zip(tmpl, ciks):
    reuse[int(t)].add(c)
multi = {int(k): len(v) for k, v in reuse.items() if len(v) > 1}
app['n_templates_shared_across_filers'] = len(multi)
app['max_filers_per_template'] = max(multi.values()) if multi else 0
app['share_segments_in_crossfiler_templates'] = float(
    np.mean([len(reuse[int(t)]) > 1 for t in tmpl]))
results['application'] = app
print(json.dumps({k: v for k, v in app.items() if not isinstance(v, dict)}, indent=1))

with open(os.path.join(RES, 'results.json'), 'w') as f:
    json.dump(results, f, indent=1)
with open(os.path.join(ROOT, 'data', 'segments_final.jsonl'), 'w') as f:
    for s in segs:
        f.write(json.dumps(s) + '\n')
print('\nsaved results.json')
