# Replication data and code

**Boilerplate-aware measurement of AI washing in regulated investment disclosure**

Xiaoguo Chen (Georgetown University) and Xukang Wang (University of Washington)

This deposit contains the minimal data set required to replicate every finding
reported in the article, together with the analysis code that produces each
table and figure.

## Contents

| File | Description |
|---|---|
| `S1_segments_annotated.csv` | The 254 annotated disclosure segments. One row per segment, 31 columns. |
| `S2_template_families.csv` | The 190 TemplateGuard families: size, registrant count, first and last filing date, lifespan, majority class, mean AICS, member segment identifiers. |
| `codebook.md` | The annotation codebook governing the class and specificity labels. |
| `code/` | Implementation of AICS, TemplateGuard, the classifiers and the statistical analyses. |
| `results/` | Derived result files from which every table and figure in the article is generated. |
| `raw_passages.jsonl` | The verbatim source passages, with the accession-level EDGAR URL of each filing. |
| `annotation_pass1.txt` | The raw annotation record, in compact form. |

## Column reference for `S1_segments_annotated.csv`

**Provenance.** `seg_id`, `doc_id`, `cik` (registrant Central Index Key),
`company`, `form` (EDGAR form type), `filed` (filing date), `channel`
(`bdc` / `fund` / `manager`), `section` (`strategy` / `risk`), `edgar_url`
(accession-level link to the source filing), `text`, `n_words`.

**Annotation.** `aidt_class` — one of `TOOL_CAP`, `TOOL_PROC`, `EXPOSURE`,
`HEDGE`, `BOIL`. `specificity_rating` — expert rating on 0–3.

**AICS scores.** `aics` is the equal-weight index in [0, 1];
`aics_agent`, `aics_artifact`, `aics_function`, `aics_evidence`,
`aics_commitment` are the five underlying facet scores.

**TemplateGuard assignments.** `template_family_id` (MinHash-LSH connected
component at Jaccard threshold 0.5, word 5-shingles, 128 permutations),
`template_family_size`, `template_family_n_registrants`,
`in_cross_filer_family`.

**Train/test split assignments.** `fold_random_seed0/1/2` give the held-out
fold index under 5-fold stratified random splitting at each of the three seeds;
`fold_document_disjoint` and `fold_template_disjoint` give the held-out fold
under grouped 5-fold splitting by source document and by template family. A
model is trained on all folds other than the one named and evaluated on it.

**Leakage audit.** `max_jaccard_to_train_seed0/1/2` give, for each segment, the
maximum shingle-Jaccard similarity to any training segment under the random
split at that seed. The audit classifies a segment as having a near-duplicate
in training when this value is at least 0.4.

## Headline numbers these files reproduce

| | |
|---|---|
| Corpus | 254 segments, 47 documents, 35 registrants, 9 form types, 2017–2026 |
| Template structure | 190 families, 160 singletons; multi-member share 37.0%, cross-filer share 30.3%, redundancy 25.2% |
| Near-duplicate leakage | 99.0% accuracy with a near-duplicate in training vs 79.1% without; gap 0.198, 95% CI [0.134, 0.266] resampling template families |
| Optimism of random splits | +0.074 macro-F1, mean over the 8 learned models |
| AIDT-Hybrid, template-disjoint | 0.792 macro-F1; `TOOL_CAP` F1 0.932 |
| AICS vs expert rating | Spearman 0.694 equal weights, 0.712 calibrated; best keyword proxy 0.289 |
| Post-hoc leakage correction | systematic overstatement across 9 models cut from +0.076 to −0.002 macro-F1 |
| Hype–hedge asymmetry | 0.222 AICS segment level; 0.204 by template family; 0.176 by registrant |

## Reproducing

```bash
pip install scikit-learn scipy numpy pandas matplotlib statsmodels datasketch

cd code
python3 segment.py            # rebuild segments from the raw passages
python3 pipeline.py corpus
python3 pipeline.py leakage
python3 pipeline.py protocol
python3 pipeline.py ablation
python3 pipeline.py sensitivity
python3 pipeline.py validation
python3 pipeline.py application
python3 robust.py             # cluster-robust re-analysis
python3 extra.py              # novel-subset estimator, template diffusion
python3 figures.py            # all figures
python3 build_deposit.py      # regenerate the two CSV files in this deposit
```

Each pipeline stage checkpoints to `results/` and skips completed work, so
stages can be interrupted and resumed. Results are averaged over 5 folds and
3 seeds and are deterministic given the seeds.

## Provenance and scope

All filing text is public regulatory material filed with the U.S. Securities
and Exchange Commission and retrieved from the EDGAR system. Every segment
carries the accession-level URL of its source filing, so any quoted passage can
be verified against the primary document. The data concern corporate
registrants only and contain no personal, sensitive or identifiable human
subject information; no anonymisation was required or applied.

The corpus is a purposive sample: passages containing AI language were sought
across issuer types, form types and filing years to obtain variety in both the
promotional and the defensive register. Prevalence figures describe the corpus
and are not extrapolated to the EDGAR filing population. The corpus is
single-coded.

## Licence

Data files are released under CC BY 4.0. Code is released under the MIT
licence. The underlying SEC filings are U.S. government public records.
